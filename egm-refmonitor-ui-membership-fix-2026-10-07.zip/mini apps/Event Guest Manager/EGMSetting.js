(() => {
  function getEl(id) {
    return document.getElementById(id);
  }

  function escapeHtml(value) {
    return String(value ?? "")
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&#39;");
  }

  const currentScriptSrc = document.currentScript instanceof HTMLScriptElement
    ? document.currentScript.src
    : "";
  const API_URL = new URL("egm_store.php", currentScriptSrc || window.location.href).toString();
  const egmShellEl = document.querySelector(".egm-shell");
  const csrfToken = egmShellEl instanceof HTMLElement
    ? String(egmShellEl.dataset.egmCsrf || "").trim()
    : "";

  async function requestStoreGet(action, params = {}) {
    const url = new URL(API_URL, window.location.href);
    url.searchParams.set("action", String(action || "").trim());
    Object.entries(params || {}).forEach(([key, value]) => {
      if (value === null || value === undefined) return;
      url.searchParams.set(String(key), String(value));
    });
    const response = await fetch(url.toString(), { credentials: "same-origin" });
    const payload = await response.json().catch(() => ({}));
    if (!response.ok || payload?.status !== "ok") {
      throw new Error(payload?.message || "درخواست ناموفق بود.");
    }
    return payload?.data && typeof payload.data === "object" ? payload.data : {};
  }

  async function requestStorePost(action, body = {}) {
    const response = await fetch(`${API_URL}?action=${encodeURIComponent(String(action || "").trim())}`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      credentials: "same-origin",
      body: JSON.stringify({ ...body, csrf: csrfToken })
    });
    const payload = await response.json().catch(() => ({}));
    if (!response.ok || payload?.status !== "ok") {
      throw new Error(payload?.message || "درخواست ناموفق بود.");
    }
    return payload;
  }

  let settingsLoadErrorMessage = "";

  function looksLikeSettingsPayload(value) {
    if (!value || typeof value !== "object" || Array.isArray(value)) {
      return false;
    }
    return [
      "active",
      "duration",
      "maintenanceMode",
      "eventAccessLocked",
      "startDate",
      "startTime",
      "endDate",
      "endTime",
      "eventName",
      "landing",
      "eventColors"
    ].some(key => Object.prototype.hasOwnProperty.call(value, key));
  }

  function extractSettingsPayload(payload) {
    if (payload?.status === "ok" && payload.data && typeof payload.data === "object") {
      return payload.data;
    }
    if (payload?.settings && typeof payload.settings === "object") {
      return payload.settings;
    }
    if (payload?.data?.settings && typeof payload.data.settings === "object") {
      return payload.data.settings;
    }
    if (looksLikeSettingsPayload(payload)) {
      return payload;
    }
    return null;
  }

  async function loadSettings() {
    try {
      settingsLoadErrorMessage = "";
      const url = new URL(API_URL);
      url.searchParams.set("action", "get_settings");
      const response = await fetch(url.toString(), { credentials: "same-origin" });
      const contentType = response.headers.get("content-type") || "";
      const responseText = await response.text().catch(() => "");
      const payload = contentType.includes("application/json")
        ? (() => {
            try {
              return JSON.parse(responseText || "{}");
            } catch {
              return {};
            }
          })()
        : {};
      const settings = extractSettingsPayload(payload);
      if (settings) {
        return settings;
      }
      const payloadKeys = payload && typeof payload === "object" && !Array.isArray(payload)
        ? Object.keys(payload).join(", ")
        : "";
      const responsePreview = responseText.slice(0, 220).replace(/\s+/g, " ").trim();
      console.error("Event Guest Manager settings response was not recognized:", {
        url: url.pathname,
        status: response.status,
        contentType,
        payloadKeys: payloadKeys || "none",
        responsePreview: responsePreview || "empty"
      });
      throw new Error(payload?.message || `بارگذاری تنظیمات ناموفق بود (${response.status}).`);
    } catch (error) {
      settingsLoadErrorMessage = error?.message || "بارگذاری تنظیمات ناموفق بود.";
      const statusEl = getEl("egm-status-text");
      if (statusEl) {
        statusEl.textContent = settingsLoadErrorMessage;
        statusEl.classList.remove("egm-status--active", "egm-status--ended", "egm-status--upcoming");
        statusEl.classList.add("egm-status--inactive");
      }
      console.error("Event Guest Manager settings load failed:", error);
    }
    return {};
  }

  async function saveSettings(settings) {
    const response = await fetch(`${API_URL}?action=save_settings`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      credentials: "same-origin",
      body: JSON.stringify({ settings, csrf: csrfToken })
    });
    const payload = await response.json().catch(() => ({}));
    if (!response.ok || payload.status !== "ok") throw new Error(payload.message || "ذخیره تنظیمات ناموفق بود.");
    return payload;
  }

  async function refreshTicketDesignTabs() {
    const response = await fetch(window.location.href, {credentials: 'same-origin', cache: 'no-store'});
    const doc = new DOMParser().parseFromString(await response.text(), 'text/html');
    const freshShell = doc.querySelector('.egm-shell');
    if (!response.ok || !freshShell) throw new Error('تنظیمات ذخیره شد؛ دریافت بلیت‌های جدید ناموفق بود.');
    const selector = '.sub-nav [data-pane^="egm-custom-number-ticket-"]';
    const freshButtons = Array.from(freshShell.querySelectorAll(selector));
    const printButton = egmShellEl?.querySelector('.sub-nav [data-pane="egm-print-card"]');
    const printPane = egmShellEl?.querySelector('.sub-pane[data-pane="egm-print-card"]');
    if (!printButton || !printPane) return;
    const valid = new Set(freshButtons.map(button => button.dataset.pane));
    egmShellEl.querySelectorAll(selector).forEach(button => {
      if (!valid.has(button.dataset.pane)) button.remove();
    });
    egmShellEl.querySelectorAll('.sub-pane[data-pane^="egm-custom-number-ticket-"]').forEach(pane => {
      if (!valid.has(pane.dataset.pane)) pane.remove();
    });
    let anchor = printButton;
    freshButtons.forEach(freshButton => {
      const key = freshButton.dataset.pane;
      let button = Array.from(egmShellEl.querySelectorAll(selector)).find(item => item.dataset.pane === key);
      if (!button) button = document.importNode(freshButton, true);
      button.textContent = freshButton.textContent;
      anchor.after(button);
      anchor = button;
      let pane = Array.from(egmShellEl.querySelectorAll('.sub-pane')).find(item => item.dataset.pane === key);
      if (!pane) {
        const freshPane = Array.from(freshShell.querySelectorAll('.sub-pane')).find(item => item.dataset.pane === key);
        if (freshPane) {
          pane = document.importNode(freshPane, true);
          pane.classList.remove('active');
          pane.querySelectorAll('script').forEach(script => script.remove());
          printPane.parentElement.append(pane);
        }
      }
      const heading = pane?.querySelector('h3');
      if (heading) heading.textContent = `${freshButton.textContent} — صفحه بلیت ۱:۱`;
    });
  }

  function initAssignAdmin() {
    const workIdInput = getEl("egm-admin-workid");
    const searchBtn = getEl("egm-admin-search-btn");
    const searchResultEl = getEl("egm-admin-search-result");
    const statusEl = getEl("egm-admin-status");
    const adminListEl = getEl("egm-admin-list");
    if (
      !(workIdInput instanceof HTMLInputElement) ||
      !(searchBtn instanceof HTMLButtonElement) ||
      !(searchResultEl instanceof HTMLElement) ||
      !(statusEl instanceof HTMLElement) ||
      !(adminListEl instanceof HTMLElement)
    ) {
      return;
    }

    let currentInvitee = null;

    const setStatus = (message, isError = false) => {
      statusEl.textContent = String(message || "").trim();
      statusEl.style.color = isError ? "#d1434a" : "";
    };

    const renderAdminList = (admins) => {
      const rows = Array.isArray(admins) ? admins : [];
      if (!rows.length) {
        adminListEl.innerHTML = '<tr><td colspan="4" class="muted">هنوز ادمینی تعیین نشده است.</td></tr>';
        return;
      }
      adminListEl.innerHTML = rows.map((item) => {
        const firstName = String(item?.firstName || "").trim();
        const lastName = String(item?.lastName || "").trim();
        const fullName = `${firstName} ${lastName}`.trim() || String(item?.fullName || "").trim() || "-";
        const workId = String(item?.workId || "").trim();
        const phone = String(item?.phone || "").trim() || "-";
        return `<tr data-admin-work-id="${escapeHtml(workId)}">
          <td>${escapeHtml(fullName)}</td>
          <td><code>${escapeHtml(workId)}</code></td>
          <td>${escapeHtml(phone)}</td>
          <td>
            <div class="egm-admin-action">
              <button type="button" class="btn ghost" data-action="remove-admin" data-work-id="${escapeHtml(workId)}">حذف</button>
            </div>
          </td>
        </tr>`;
      }).join("");
    };

    const renderSearchResult = (invitee) => {
      currentInvitee = invitee && typeof invitee === "object" ? invitee : null;
      if (!currentInvitee) {
        searchResultEl.classList.add("hidden");
        searchResultEl.innerHTML = "";
        return;
      }
      const firstName = String(currentInvitee.firstName || "").trim();
      const lastName = String(currentInvitee.lastName || "").trim();
      const fullName = `${firstName} ${lastName}`.trim() || String(currentInvitee.fullName || "").trim() || "-";
      const workId = String(currentInvitee.workId || "").trim();
      const phone = String(currentInvitee.phone || "").trim() || "-";
      const isAdmin = Boolean(currentInvitee.isAdmin);
      const buttonLabel = isAdmin ? "ادمین است" : "افزودن به عنوان ادمین";
      const buttonDisabled = isAdmin ? " disabled" : "";
      searchResultEl.innerHTML = `<div class="egm-admin-search-meta">
          <strong>${escapeHtml(fullName)}</strong>
          <div><code>${escapeHtml(workId)}</code></div>
          <div class="muted small">${escapeHtml(phone)}</div>
        </div>
        <button type="button" class="btn primary"${buttonDisabled} data-action="assign-admin" data-work-id="${escapeHtml(workId)}">${escapeHtml(buttonLabel)}</button>`;
      searchResultEl.classList.remove("hidden");
    };

    const loadAdmins = async () => {
      const data = await requestStoreGet("get_admin_assignments");
      renderAdminList(data?.admins || []);
    };

    const applyAssignment = async (workId, isAdmin) => {
      const normalizedWorkId = String(workId || "").trim();
      if (!normalizedWorkId) return;
      setStatus("در حال ذخیره...");
      const payload = await requestStorePost("set_admin_assignment", {
        workId: normalizedWorkId,
        isAdmin: Boolean(isAdmin)
      });
      const data = payload?.data && typeof payload.data === "object" ? payload.data : {};
      renderAdminList(data?.admins || []);
      const invitee = data?.invitee && typeof data.invitee === "object" ? data.invitee : null;
      if (invitee && String(invitee.workId || "").trim() === normalizedWorkId) {
        renderSearchResult(invitee);
      }
      setStatus(payload?.message || (isAdmin ? "ادمین تعیین شد." : "ادمین حذف شد."));
    };

    const searchInvitee = async () => {
      const workId = String(workIdInput.value || "").trim();
      if (!workId) {
        setStatus("لطفا شناسه کاری را وارد کنید.", true);
        renderSearchResult(null);
        return;
      }
      setStatus("در حال جستجو...");
      try {
        const data = await requestStoreGet("search_invitee_admin", { work_id: workId });
        const invitee = data?.invitee && typeof data.invitee === "object" ? data.invitee : null;
        if (!invitee) {
          renderSearchResult(null);
          setStatus("کاربر پیدا نشد.", true);
          return;
        }
        renderSearchResult(invitee);
        setStatus("کاربر پیدا شد.");
      } catch (error) {
        renderSearchResult(null);
        setStatus(error?.message || "جستجو ناموفق بود.", true);
      }
    };

    searchBtn.addEventListener("click", () => {
      void searchInvitee();
    });

    workIdInput.addEventListener("keydown", (event) => {
      if (event.key !== "Enter") return;
      event.preventDefault();
      void searchInvitee();
    });

    searchResultEl.addEventListener("click", (event) => {
      const target = event.target;
      if (!(target instanceof Element)) return;
      const button = target.closest('[data-action="assign-admin"]');
      if (!(button instanceof HTMLButtonElement)) return;
      const workId = String(button.getAttribute("data-work-id") || "").trim();
      if (!workId) return;
      button.disabled = true;
      void applyAssignment(workId, true).catch((error) => {
        setStatus(error?.message || "تعیین ادمین ناموفق بود.", true);
      }).finally(() => {
        button.disabled = false;
      });
    });

    adminListEl.addEventListener("click", (event) => {
      const target = event.target;
      if (!(target instanceof Element)) return;
      const button = target.closest('[data-action="remove-admin"]');
      if (!(button instanceof HTMLButtonElement)) return;
      const workId = String(button.getAttribute("data-work-id") || "").trim();
      if (!workId) return;
      button.disabled = true;
      void applyAssignment(workId, false).catch((error) => {
        setStatus(error?.message || "حذف ادمین ناموفق بود.", true);
      }).finally(() => {
        button.disabled = false;
      });
    });

    void loadAdmins().catch((error) => {
      renderAdminList([]);
      setStatus(error?.message || "بارگذاری ادمین‌ها ناموفق بود.", true);
    });
  }

  function setDurationFieldsEnabled(enabled) {
    const startDate = getEl("egm-duration-start");
    const startTime = getEl("egm-duration-start-time");
    const endDate = getEl("egm-duration-end");
    const endTime = getEl("egm-duration-end-time");

    [startDate, startTime, endDate, endTime].forEach(field => {
      if (field) {
        field.disabled = !enabled;
      }
    });
  }

  function getTehranDateTimeParts(date = new Date()) {
    try {
      const formatter = new Intl.DateTimeFormat("en-CA", {
        timeZone: "Asia/Tehran",
        year: "numeric",
        month: "2-digit",
        day: "2-digit",
        hour: "2-digit",
        minute: "2-digit",
        hour12: false
      });
      const parts = formatter.formatToParts(date);
      const year = parts.find(p => p.type === "year")?.value ?? "";
      const month = parts.find(p => p.type === "month")?.value ?? "";
      const day = parts.find(p => p.type === "day")?.value ?? "";
      const hour = parts.find(p => p.type === "hour")?.value ?? "00";
      const minute = parts.find(p => p.type === "minute")?.value ?? "00";
      return {
        date: `${year}-${month}-${day}`,
        time: `${hour}:${minute}`
      };
    } catch {
      const fallback = new Date();
      const year = String(fallback.getFullYear());
      const month = String(fallback.getMonth() + 1).padStart(2, "0");
      const day = String(fallback.getDate()).padStart(2, "0");
      const hour = String(fallback.getHours()).padStart(2, "0");
      const minute = String(fallback.getMinutes()).padStart(2, "0");
      return {
        date: `${year}-${month}-${day}`,
        time: `${hour}:${minute}`
      };
    }
  }

  function parseTimeToSeconds(value) {
    if (!value) return null;
    const normalized = String(value).trim();
    const parts = normalized.split(":").map((part) => Number(part));
    if (parts.length < 2 || parts.length > 3 || parts.some((n) => !Number.isFinite(n))) {
      return null;
    }
    const [hours, minutes, seconds = 0] = parts;
    return hours * 3600 + minutes * 60 + seconds;
  }

  function compareGregorianDates(a = "", b = "") {
    const left = (a || "").trim();
    const right = (b || "").trim();
    if (!left || !right) return null;
    if (left === right) return 0;
    return left > right ? 1 : -1;
  }

  function getCurrentLocalSeconds() {
    const now = new Date();
    return now.getHours() * 3600 + now.getMinutes() * 60 + now.getSeconds();
  }

  function describeSameDayDurationState(startTime, endTime) {
    const nowSeconds = getCurrentTehranSeconds();
    const startSeconds = parseTimeToSeconds(startTime);
    const endSeconds = parseTimeToSeconds(endTime);

    if (endSeconds !== null && nowSeconds >= endSeconds) {
      return "پایان یافته";
    }
    if (startSeconds !== null && nowSeconds >= startSeconds) {
      return "فعال";
    }
    if (startSeconds !== null && nowSeconds < startSeconds) {
      return "در انتظار شروع";
    }
    return "در انتظار شروع";
  }

  function getCurrentTehranSeconds() {
    const parts = getTehranDateTimeParts();
    return parseTimeToSeconds(parts.time) ?? getCurrentLocalSeconds();
  }

  function updateStatus() {
    const statusEl = getEl("egm-status-text");
    const activeToggle = getEl("egm-active-toggle");
    const durationToggle = getEl("egm-duration-toggle");
    const startDate = getEl("egm-duration-start");
    const startTime = getEl("egm-duration-start-time");
    const endDate = getEl("egm-duration-end");
    const endTime = getEl("egm-duration-end-time");

    if (!statusEl) return;
    const setStatus = (label, tone) => {
      statusEl.textContent = label;
      statusEl.classList.remove(
        "egm-status--active",
        "egm-status--ended",
        "egm-status--upcoming",
        "egm-status--inactive"
      );
      if (tone) {
        statusEl.classList.add(`egm-status--${tone}`);
      }
    };
    const setPrizeAccess = (enabled) => {
      const prizeForm = document.getElementById("egm-prize-form");
      const prizeList = document.getElementById("egm-prize-list");
      const prizeSection = document.getElementById("egm-prize-section");
      const targets = [
        ...(prizeForm?.querySelectorAll("input, select, button") || []),
        ...(prizeList?.querySelectorAll("input, select, button") || [])
      ];
      targets.forEach(el => {
        el.disabled = !enabled;
      });
      if (prizeSection) {
        prizeSection.classList.toggle("egm-prize-disabled", !enabled);
      }
    };

    if (settingsLoadErrorMessage) {
      setStatus(settingsLoadErrorMessage, "inactive");
      setPrizeAccess(true);
      return;
    }

    if (durationToggle?.checked) {
      const normalizedStartDate = (startDate?.value || "").trim();
      const normalizedEndDate = (endDate?.value || "").trim();
      const todayParts = getTehranDateTimeParts();
      const startRelation = compareGregorianDates(normalizedStartDate, todayParts.date);
      const endRelation = compareGregorianDates(normalizedEndDate, todayParts.date);

      if (!normalizedStartDate || !todayParts.date) {
        setStatus("غیرفعال", "inactive");
        setPrizeAccess(true);
        return;
      }

      if (startRelation === 1) {
        setStatus("در انتظار شروع", "upcoming");
        setPrizeAccess(true);
        return;
      }

      if (endRelation !== null && endRelation === -1) {
        setStatus("پایان یافته", "ended");
        setPrizeAccess(true);
        return;
      }

      if (startRelation === 0) {
        const state = describeSameDayDurationState(
          startTime?.value ?? "",
          endTime?.value ?? ""
        );
        if (state === "پایان یافته") {
          setStatus(state, "ended");
          setPrizeAccess(true);
        } else if (state === "فعال") {
          setStatus(state, "active");
          setPrizeAccess(false);
        } else {
          setStatus(state, "upcoming");
          setPrizeAccess(true);
        }
        return;
      }

      if (endRelation === 0) {
        const state = describeSameDayDurationState(
          startTime?.value ?? "",
          endTime?.value ?? ""
        );
        if (state === "پایان یافته") {
          setStatus(state, "ended");
          setPrizeAccess(true);
        } else if (state === "فعال") {
          setStatus(state, "active");
          setPrizeAccess(false);
        } else {
          setStatus(state, "upcoming");
          setPrizeAccess(true);
        }
        return;
      }

      setStatus("فعال", "active");
      setPrizeAccess(false);
      return;
    }

    const isActive = Boolean(activeToggle?.checked);
    setStatus(isActive ? "فعال" : "غیرفعال", isActive ? "active" : "inactive");
    setPrizeAccess(true);
  }

  function syncToggles({ activeToggle, durationToggle }) {
    if (!activeToggle || !durationToggle) return;
    if (activeToggle.checked) {
      durationToggle.checked = false;
    } else if (durationToggle.checked) {
      activeToggle.checked = false;
    }
    setDurationFieldsEnabled(durationToggle.checked);
    updateStatus();
  }

  const settingsCache = {};

  function renderTicketTypes(rawTickets) {
    const root = getEl("egm-ticket-types");
    if (!root) return;
    const tickets = Array.isArray(rawTickets) && rawTickets.length ? rawTickets : [{ id: "default", title: "بلیت شماره‌دار" }];
    const escape = value => String(value).replace(/[&<>\"]/g, char => ({'&':'&amp;','<':'&lt;','>':'&gt;','\"':'&quot;'}[char]));
    root.innerHTML = tickets.map((ticket, index) => {
      const id = String(ticket.id || `ticket-${index + 1}`).replace(/[^a-z0-9_-]/gi, '');
      const displayTitle = value => value === 'Custom Number Ticket' ? 'بلیت شماره‌دار' : value;
      const options = tickets.slice(0, index).map(other => `<option value="${escape(other.id)}" ${ticket.dependsOn === other.id ? 'selected' : ''}>${escape(displayTitle(other.title))}</option>`).join('');
      return `<div class="field" data-ticket-type-row style="display:grid;grid-template-columns:1fr auto;gap:8px"><input type="text" maxlength="100" value="${escape(displayTitle(ticket.title || `بلیت ${index + 1}`))}" data-ticket-title data-ticket-id="${id}" aria-label="عنوان بلیت ${index + 1}" /><button type="button" class="btn ghost" data-remove-ticket-type>حذف</button><label style="grid-column:1 / -1">پیشنهاد تعداد از بلیت <select data-ticket-depends-on><option value="">بدون وابستگی</option>${options}</select></label></div>`;
    }).join("");
  }

  function collectTicketTypes() {
    return Array.from(document.querySelectorAll("[data-ticket-type-row]")).map((row, index) => {
      const input = row.querySelector("[data-ticket-title]");
      return { id: input?.dataset.ticketId || `ticket-${Date.now()}-${index}`, title: String(input?.value || `بلیت ${index + 1}`).trim(), dependsOn: row.querySelector('[data-ticket-depends-on]')?.value || '' };
    }).filter(ticket => ticket.title);
  }

  function applySettings(settings) {
    const activeToggle = getEl("egm-active-toggle");
    const durationToggle = getEl("egm-duration-toggle");
    const maintenanceToggle = getEl("egm-maintenance-toggle");
    const eventAccessLockToggle = getEl("egm-event-access-lock-toggle");
    const autoPrintToggle = getEl("egm-auto-print-toggle");
    const doublePrintToggle = getEl("egm-double-print-toggle");
    const customNumberTicketToggle = getEl("egm-custom-number-ticket-toggle");
    const ticketOnlyToggle = getEl("egm-ticket-only-toggle");
    const startDate = getEl("egm-duration-start");
    const startTime = getEl("egm-duration-start-time");
    const endDate = getEl("egm-duration-end");
    const endTime = getEl("egm-duration-end-time");
    const adminPasscodeState = getEl("egm-admin-passcode-state");

    Object.assign(settingsCache, settings);
    if (activeToggle) activeToggle.checked = Boolean(settings.active);
    if (durationToggle) durationToggle.checked = Boolean(settings.duration);
    if (maintenanceToggle) maintenanceToggle.checked = Boolean(settings.maintenanceMode);
    if (eventAccessLockToggle) eventAccessLockToggle.checked = Boolean(settings.eventAccessLocked);
    if (autoPrintToggle) autoPrintToggle.checked = Boolean(settings.printSettings?.autoPrint);
    if (doublePrintToggle) doublePrintToggle.checked = Boolean(settings.printSettings?.doublePrint);
    if (customNumberTicketToggle) customNumberTicketToggle.checked = Boolean(settings.customNumberTicketSettings?.active);
    if (ticketOnlyToggle) ticketOnlyToggle.checked = Boolean(settings.customNumberTicketSettings?.ticketOnly);
    renderTicketTypes(settings.customNumberTicketSettings?.tickets);
    if (startDate && typeof settings.startDate === "string") startDate.value = settings.startDate;
    if (startTime && typeof settings.startTime === "string") startTime.value = settings.startTime;
    if (endDate && typeof settings.endDate === "string") endDate.value = settings.endDate;
    if (endTime && typeof settings.endTime === "string") endTime.value = settings.endTime;
    if (adminPasscodeState) adminPasscodeState.textContent = settings.adminPasscode?.configured ? "کد تنظیم شده است" : "تنظیم نشده";
    syncToggles({ activeToggle, durationToggle });
  }

  function collectSettings() {
    const activeToggle = getEl("egm-active-toggle");
    const durationToggle = getEl("egm-duration-toggle");
    const maintenanceToggle = getEl("egm-maintenance-toggle");
    const eventAccessLockToggle = getEl("egm-event-access-lock-toggle");
    const autoPrintToggle = getEl("egm-auto-print-toggle");
    const doublePrintToggle = getEl("egm-double-print-toggle");
    const customNumberTicketToggle = getEl("egm-custom-number-ticket-toggle");
    const ticketOnlyToggle = getEl("egm-ticket-only-toggle");
    const startDate = getEl("egm-duration-start");
    const startTime = getEl("egm-duration-start-time");
    const endDate = getEl("egm-duration-end");
    const endTime = getEl("egm-duration-end-time");
    const collected = {
      active: Boolean(activeToggle?.checked),
      duration: Boolean(durationToggle?.checked),
      maintenanceMode: Boolean(maintenanceToggle?.checked),
      eventAccessLocked: Boolean(eventAccessLockToggle?.checked),
      printSettings: {
        autoPrint: Boolean(autoPrintToggle?.checked),
        doublePrint: Boolean(doublePrintToggle?.checked)
      },
      customNumberTicketSettings: {
        active: Boolean(customNumberTicketToggle?.checked),
        ticketOnly: Boolean(ticketOnlyToggle?.checked),
        tickets: collectTicketTypes()
      },
      startDate: startDate?.value ?? "",
      startTime: startTime?.value ?? "",
      endDate: endDate?.value ?? "",
      endTime: endTime?.value ?? ""
    };
    return collected;
  }

  function normalizeLandingSection(section, index = 0, options = {}) {
    if (!section || typeof section !== "object") {
      return null;
    }
    const title = String(section.title ?? "").trim();
    const text = String(section.text ?? section.html ?? "").replace(/\r\n?/g, "\n").trim();
    if (!options.keepEmpty && !title && !text) {
      return null;
    }
    return {
      id: String(section.id ?? `landing_section_${Date.now()}_${index}`).trim() || `landing_section_${Date.now()}_${index}`,
      title,
      text
    };
  }

  function normalizeLandingPayload(raw) {
    const source = raw && typeof raw === "object" ? raw : {};
    const sections = Array.isArray(source.sections)
      ? source.sections.map(normalizeLandingSection).filter(Boolean)
      : [];
    return {
      title: String(source.title ?? "").trim(),
      subtitle: String(source.subtitle ?? "").replace(/\r\n?/g, "\n").trim(),
      sections
    };
  }

  function landingSectionTemplate(section, index, total) {
    const safe = normalizeLandingSection(section, index, { keepEmpty: true }) || { id: `landing_section_${Date.now()}_${index}`, title: "", text: "" };
    return `
      <div class="egm-landing-section" data-landing-section-id="${escapeHtml(safe.id)}">
        <div class="egm-landing-section-toolbar">
          <strong>Section ${index + 1}</strong>
          <div class="egm-landing-actions">
            <button type="button" class="btn ghost" data-landing-action="move-up" ${index <= 0 ? "disabled" : ""}>بالا</button>
            <button type="button" class="btn ghost" data-landing-action="move-down" ${index >= total - 1 ? "disabled" : ""}>پایین</button>
            <button type="button" class="btn ghost" data-landing-action="remove">حذف</button>
          </div>
        </div>
        <label class="field full">
          <span>عنوان بخش</span>
          <input type="text" data-landing-field="title" value="${escapeHtml(safe.title)}" autocomplete="off" />
        </label>
        <label class="field full">
          <span>متن بخش</span>
          <div class="egm-rich-text-tools" aria-label="ابزار متن بخش">
            <button type="button" class="btn ghost" data-landing-format="bold">B</button>
            <button type="button" class="btn ghost" data-landing-format="list">فهرست</button>
            <button type="button" class="btn ghost" data-landing-format="header">H</button>
            <button type="button" class="btn ghost" data-landing-format="link">پیوند</button>
          </div>
          <textarea data-landing-field="text" rows="7">${escapeHtml(safe.text)}</textarea>
        </label>
      </div>
    `;
  }

  function getLandingEditorElements() {
    const titleInput = getEl("egm-landing-title");
    const subtitleInput = getEl("egm-landing-subtitle");
    const sectionsEl = getEl("egm-landing-sections");
    const addButton = getEl("egm-landing-add-section");
    const saveButton = getEl("egm-landing-save");
    const statusEl = getEl("egm-landing-status");
    if (
      !(titleInput instanceof HTMLInputElement) ||
      !(subtitleInput instanceof HTMLTextAreaElement) ||
      !(sectionsEl instanceof HTMLElement)
    ) {
      return null;
    }
    return {
      titleInput,
      subtitleInput,
      sectionsEl,
      addButton: addButton instanceof HTMLButtonElement ? addButton : null,
      saveButton: saveButton instanceof HTMLButtonElement ? saveButton : null,
      statusEl: statusEl instanceof HTMLElement ? statusEl : null
    };
  }

  function setLandingStatus(message, isError = false) {
    const statusEl = getEl("egm-landing-status");
    if (!(statusEl instanceof HTMLElement)) return;
    statusEl.textContent = String(message || "").trim();
    statusEl.style.color = isError ? "#d1434a" : "";
  }

  function renderLandingSections(sections) {
    const elements = getLandingEditorElements();
    if (!elements) return;
    const items = Array.isArray(sections)
      ? sections.map((section, index) => normalizeLandingSection(section, index, { keepEmpty: true })).filter(Boolean)
      : [];
    elements.sectionsEl.innerHTML = items
      .map((section, index) => landingSectionTemplate(section, index, items.length))
      .join("");
  }

  function collectLandingFromDom(options = {}) {
    const elements = getLandingEditorElements();
    if (!elements) return null;
    const sections = Array.from(elements.sectionsEl.querySelectorAll("[data-landing-section-id]"))
      .map((sectionEl, index) => {
        if (!(sectionEl instanceof HTMLElement)) return null;
        const titleField = sectionEl.querySelector('[data-landing-field="title"]');
        const textField = sectionEl.querySelector('[data-landing-field="text"]');
        return normalizeLandingSection({
          id: sectionEl.dataset.landingSectionId || `landing_section_${Date.now()}_${index}`,
          title: titleField instanceof HTMLInputElement ? titleField.value : "",
          text: textField instanceof HTMLTextAreaElement ? textField.value : ""
        }, index, options);
      })
      .filter(Boolean);
    return {
      title: elements.titleInput.value,
      subtitle: elements.subtitleInput.value,
      sections
    };
  }

  function applyLinkShortcutToTextarea(textarea) {
    if (!(textarea instanceof HTMLTextAreaElement)) return;
    const value = String(textarea.value || "");
    const start = Math.max(0, textarea.selectionStart ?? 0);
    const end = Math.max(start, textarea.selectionEnd ?? start);
    const selectedText = value.slice(start, end) || "link text";
    const markup = `<a href="">${selectedText}</a>`;
    const labelStart = start + '<a href="">'.length;
    replaceTextareaRange(textarea, start, end, markup, labelStart, labelStart + selectedText.length);
  }

  function applyLandingFormat(textarea, format) {
    if (!(textarea instanceof HTMLTextAreaElement)) return;
    if (format === "bold") {
      applyBoldShortcutToTextarea(textarea);
      return;
    }
    if (format === "list") {
      applyListShortcutToTextarea(textarea);
      return;
    }
    if (format === "header") {
      applyHeaderShortcutToTextarea(textarea);
      return;
    }
    if (format === "link") {
      applyLinkShortcutToTextarea(textarea);
    }
  }

  function initLandingEditor(initialSettings = {}) {
    const elements = getLandingEditorElements();
    if (!elements || elements.sectionsEl.dataset.landingReady === "1") return;
    elements.sectionsEl.dataset.landingReady = "1";
    const initialLanding = normalizeLandingPayload(initialSettings?.landing || {});
    elements.titleInput.value = initialLanding.title;
    elements.subtitleInput.value = initialLanding.subtitle;
    renderLandingSections(initialLanding.sections);

    elements.addButton?.addEventListener("click", () => {
      const current = collectLandingFromDom({ keepEmpty: true }) || { sections: [] };
      current.sections.push({
        id: `landing_section_${Date.now()}`,
        title: "",
        text: ""
      });
      renderLandingSections(current.sections);
      setLandingStatus("");
    });

    elements.sectionsEl.addEventListener("click", (event) => {
      const target = event.target;
      if (!(target instanceof Element)) return;
      const formatButton = target.closest("[data-landing-format]");
      if (formatButton instanceof HTMLElement) {
        const sectionEl = formatButton.closest("[data-landing-section-id]");
        const textarea = sectionEl?.querySelector('[data-landing-field="text"]');
        if (textarea instanceof HTMLTextAreaElement) {
          textarea.focus();
          applyLandingFormat(textarea, String(formatButton.getAttribute("data-landing-format") || ""));
          setLandingStatus("");
        }
        return;
      }
      const actionButton = target.closest("[data-landing-action]");
      if (!(actionButton instanceof HTMLElement)) return;
      const action = String(actionButton.getAttribute("data-landing-action") || "");
      const sectionEl = actionButton.closest("[data-landing-section-id]");
      const current = collectLandingFromDom({ keepEmpty: true });
      if (!sectionEl || !current) return;
      const index = Array.from(elements.sectionsEl.querySelectorAll("[data-landing-section-id]")).indexOf(sectionEl);
      if (index < 0) return;
      if (action === "remove") {
        current.sections.splice(index, 1);
      } else if (action === "move-up" && index > 0) {
        [current.sections[index - 1], current.sections[index]] = [current.sections[index], current.sections[index - 1]];
      } else if (action === "move-down" && index < current.sections.length - 1) {
        [current.sections[index + 1], current.sections[index]] = [current.sections[index], current.sections[index + 1]];
      }
      renderLandingSections(current.sections);
      setLandingStatus("");
    });

    elements.sectionsEl.addEventListener("keydown", (event) => {
      const target = event.target;
      if (!(target instanceof HTMLTextAreaElement) || !target.matches('[data-landing-field="text"]')) return;
      const hasCtrl = event.ctrlKey || event.metaKey;
      if (hasCtrl && !event.altKey && isShortcutLetterKey(event, "B")) {
        event.preventDefault();
        applyBoldShortcutToTextarea(target);
        return;
      }
      if (hasCtrl && !event.altKey && isShortcutLetterKey(event, "L")) {
        event.preventDefault();
        applyListShortcutToTextarea(target);
        return;
      }
      const isOneKey = event.key === "1" || event.code === "Digit1" || event.code === "Numpad1";
      if (event.ctrlKey && event.altKey && isOneKey) {
        event.preventDefault();
        applyHeaderShortcutToTextarea(target);
      }
    });

    elements.saveButton?.addEventListener("click", async () => {
      const landing = collectLandingFromDom();
      if (!landing) return;
      elements.saveButton.disabled = true;
      setLandingStatus("در حال ذخیره...");
      try {
        await requestStorePost("save_settings", { settings: { landing } });
        Object.assign(settingsCache, { landing });
        setLandingStatus("ذخیره شد.");
      } catch (error) {
        setLandingStatus(error?.message || "ذخیره صفحه آغازین ناموفق بود.", true);
      } finally {
        elements.saveButton.disabled = false;
      }
    });
  }

  function setRewardGuideStatus(message, isError = false) {
    const statusEl = getEl("egm-reward-guide-status");
    if (!(statusEl instanceof HTMLElement)) return;
    statusEl.textContent = String(message || "").trim();
    statusEl.style.color = isError ? "#d1434a" : "";
  }

  function normalizeRewardPrizeDisplay(raw = {}) {
    const source = raw && typeof raw === "object" ? raw : {};
    return {
      nonValuePrizeDescribe: Object.prototype.hasOwnProperty.call(source, "nonValuePrizeDescribe")
        ? Boolean(source.nonValuePrizeDescribe)
        : Boolean(source.non_value_prize_describe),
      showPrize: Object.prototype.hasOwnProperty.call(source, "showPrize")
        ? Boolean(source.showPrize)
        : true,
      hiddenText: String(source.hiddenText ?? source.hidden_text ?? "").trim()
    };
  }

  function setRewardAdvancedStatus(message, isError = false) {
    const statusEl = getEl("egm-reward-advanced-status");
    if (!(statusEl instanceof HTMLElement)) return;
    statusEl.textContent = String(message || "").trim();
    statusEl.style.color = isError ? "#d1434a" : "";
  }

  function syncRewardAdvancedFields() {
    const nonValueDescribeToggle = getEl("egm-reward-non-value-describe-toggle");
    const showPrizeToggle = getEl("egm-reward-show-prize-toggle");
    const hiddenTextInput = getEl("egm-reward-hidden-prize-text");
    if (!(showPrizeToggle instanceof HTMLInputElement) || !(hiddenTextInput instanceof HTMLInputElement)) {
      return;
    }
    const isDescribeMode = nonValueDescribeToggle instanceof HTMLInputElement && nonValueDescribeToggle.checked;
    showPrizeToggle.disabled = isDescribeMode;
    const isHiddenMode = !isDescribeMode && !showPrizeToggle.checked;
    hiddenTextInput.disabled = !isHiddenMode;
    hiddenTextInput.required = isHiddenMode;
  }

  function isShortcutLetterKey(event, letter) {
    const token = String(letter || "").trim().toUpperCase();
    if (!/^[A-Z]$/.test(token)) return false;
    const byKey = String(event?.key || "").toLowerCase() === token.toLowerCase();
    const byCode = String(event?.code || "").toUpperCase() === `KEY${token}`;
    return byKey || byCode;
  }

  function replaceTextareaRange(textarea, start, end, replacement, selectionStart = null, selectionEnd = null) {
    if (!(textarea instanceof HTMLTextAreaElement)) return;
    const value = String(textarea.value || "");
    const safeStart = Math.max(0, Math.min(value.length, Number.isFinite(start) ? start : 0));
    const safeEnd = Math.max(safeStart, Math.min(value.length, Number.isFinite(end) ? end : safeStart));
    const nextValue = `${value.slice(0, safeStart)}${replacement}${value.slice(safeEnd)}`;
    textarea.value = nextValue;
    const defaultCaret = safeStart + String(replacement || "").length;
    const nextSelectionStart = Number.isFinite(selectionStart) ? Math.max(0, Math.min(nextValue.length, selectionStart)) : defaultCaret;
    const nextSelectionEnd = Number.isFinite(selectionEnd) ? Math.max(nextSelectionStart, Math.min(nextValue.length, selectionEnd)) : nextSelectionStart;
    textarea.selectionStart = nextSelectionStart;
    textarea.selectionEnd = nextSelectionEnd;
    textarea.dispatchEvent(new Event("input", { bubbles: true }));
  }

  function applyBoldShortcutToTextarea(textarea) {
    if (!(textarea instanceof HTMLTextAreaElement)) return;
    const value = String(textarea.value || "");
    const start = Math.max(0, textarea.selectionStart ?? 0);
    const end = Math.max(start, textarea.selectionEnd ?? start);
    if (start === end) {
      const wrapped = "<b></b>";
      const caret = start + 3;
      replaceTextareaRange(textarea, start, end, wrapped, caret, caret);
      return;
    }
    const selectedText = value.slice(start, end);
    const wrapped = `<b>${selectedText}</b>`;
    replaceTextareaRange(textarea, start, end, wrapped, start + 3, start + 3 + selectedText.length);
  }

  function applyListShortcutToTextarea(textarea) {
    if (!(textarea instanceof HTMLTextAreaElement)) return;
    const value = String(textarea.value || "");
    const rawStart = Math.max(0, textarea.selectionStart ?? 0);
    const rawEnd = Math.max(rawStart, textarea.selectionEnd ?? rawStart);
    const lineStart = value.lastIndexOf("\n", Math.max(0, rawStart - 1)) + 1;
    const lineEndIndex = value.indexOf("\n", rawEnd);
    const lineEnd = lineEndIndex >= 0 ? lineEndIndex : value.length;
    const selectedBlock = value.slice(lineStart, lineEnd);
    const lines = selectedBlock
      .split("\n")
      .map((line) => String(line || "").trim())
      .filter((line) => line !== "");
    if (!lines.length) return;
    const listBody = lines.map((line) => `  <li>${line}</li>`).join("\n");
    replaceTextareaRange(textarea, lineStart, lineEnd, `<ul>\n${listBody}\n</ul>`);
  }

  function applyHeaderShortcutToTextarea(textarea) {
    if (!(textarea instanceof HTMLTextAreaElement)) return;
    const value = String(textarea.value || "");
    const start = Math.max(0, textarea.selectionStart ?? 0);
    const end = Math.max(start, textarea.selectionEnd ?? start);
    const lineStart = value.lastIndexOf("\n", start - 1) + 1;
    const lineEndIndex = value.indexOf("\n", end);
    const lineEnd = lineEndIndex >= 0 ? lineEndIndex : value.length;
    const line = value.slice(lineStart, lineEnd);
    const lineTrimmedLeft = line.replace(/^\s+/, "");
    const leftPaddingLength = line.length - lineTrimmedLeft.length;
    const leftPadding = line.slice(0, leftPaddingLength);
    const raw = lineTrimmedLeft.replace(/^#\s+/, "");
    const nextLine = `${leftPadding}# ${raw}`;
    textarea.value = `${value.slice(0, lineStart)}${nextLine}${value.slice(lineEnd)}`;
    const caret = lineStart + nextLine.length;
    textarea.selectionStart = caret;
    textarea.selectionEnd = caret;
    textarea.dispatchEvent(new Event("input", { bubbles: true }));
  }

  function applyRewardGuideEditorShortcut(event) {
    const target = event.target;
    if (!(target instanceof HTMLTextAreaElement) || target.id !== "egm-reward-guide-text") return;
    const hasCtrl = event.ctrlKey || event.metaKey;
    if (hasCtrl && !event.altKey && isShortcutLetterKey(event, "B")) {
      event.preventDefault();
      event.stopPropagation();
      applyBoldShortcutToTextarea(target);
      return;
    }
    if (hasCtrl && !event.altKey && isShortcutLetterKey(event, "L")) {
      event.preventDefault();
      event.stopPropagation();
      applyListShortcutToTextarea(target);
      return;
    }
    const isOneKey = event.key === "1" || event.code === "Digit1" || event.code === "Numpad1";
    if (event.ctrlKey && event.altKey && isOneKey) {
      event.preventDefault();
      applyHeaderShortcutToTextarea(target);
    }
  }

  function organizeControlPanel() {
    const seating = document.querySelector('[data-egm-seating-content]');
    const printing = document.querySelector('[data-egm-print-switches]');
    const tickets = document.querySelector('[data-egm-ticket-settings-content]');
    const printSave = document.querySelector('[data-egm-print-save]');
    const admin = document.querySelector('[data-egm-admin-passcode-content]');
    const seatCard = document.querySelector('[data-pane="egm-main"] [data-seat-map-editor]');
    const ticketCard = getEl('egm-ticket-types')?.closest('.card');
    const passcodeCard = getEl('egm-admin-passcode-save')?.closest('.card');
    if (seating && seatCard) seating.append(seatCard);
    if (printing) ['egm-auto-print-toggle', 'egm-double-print-toggle', 'egm-custom-number-ticket-toggle', 'egm-ticket-only-toggle'].forEach(id => {
      const row = getEl(id)?.closest('.egm-switch');
      if (row) printing.append(row);
    });
    if (tickets && ticketCard) tickets.append(ticketCard);
    const ticketSaveButton = getEl('egm-save-ticket-types');
    const ticketStatus = getEl('egm-ticket-types-status');
    if (printSave && ticketSaveButton) printSave.append(ticketSaveButton);
    if (printSave && ticketStatus) printSave.append(ticketStatus);
    if (admin && passcodeCard) admin.append(passcodeCard);
  }

  function initControlPanelTabs() {
    const pane = document.querySelector('.sub-pane[data-pane="egm-main"]');
    if (!(pane instanceof HTMLElement)) return;
    if (pane.dataset.controlPanelTabsInitialized === "1") return;
    pane.dataset.controlPanelTabsInitialized = "1";

    const triggers = Array.from(pane.querySelectorAll("[data-egm-control-panel-trigger]"));
    const sections = Array.from(pane.querySelectorAll("[data-egm-control-panel-section]"));
    if (!triggers.length || !sections.length) return;

    const activate = (key) => {
      const fallbackKey = String(triggers[0]?.getAttribute("data-egm-control-panel-trigger") || "general").trim() || "general";
      const activeKey = String(key || fallbackKey).trim() || fallbackKey;
      try { sessionStorage.setItem('egmControlPanelTab', activeKey); } catch {}
      triggers.forEach((trigger) => {
        if (!(trigger instanceof HTMLElement)) return;
        const isActive = String(trigger.getAttribute("data-egm-control-panel-trigger") || "") === activeKey;
        trigger.classList.toggle("active", isActive);
        trigger.setAttribute("aria-selected", isActive ? "true" : "false");
      });
      sections.forEach((section) => {
        if (!(section instanceof HTMLElement)) return;
        section.hidden = String(section.getAttribute("data-egm-control-panel-section") || "") !== activeKey;
      });
    };

    triggers.forEach((trigger) => {
      trigger.addEventListener("click", () => {
        activate(trigger.getAttribute("data-egm-control-panel-trigger") || "");
      });
    });

    const activeTrigger = triggers.find((trigger) => trigger instanceof HTMLElement && trigger.classList.contains("active"));
    let savedKey = '';
    try { savedKey = sessionStorage.getItem('egmControlPanelTab') || ''; } catch {}
    const savedTrigger = triggers.find((trigger) => trigger.getAttribute('data-egm-control-panel-trigger') === savedKey);
    activate(savedTrigger?.getAttribute('data-egm-control-panel-trigger') || activeTrigger?.getAttribute("data-egm-control-panel-trigger") || "");
  }

  function initCampaignLinker() {
    const card = getEl("egm-campaign-linker-card");
    if (!(card instanceof HTMLElement) || card.dataset.egmLinkerInitialized === "1") return;
    card.dataset.egmLinkerInitialized = "1";

    const pathInput = getEl("egm-linker-path");
    const destinationInput = getEl("egm-linker-destination");
    const checkBtn = getEl("egm-linker-check");
    const createBtn = getEl("egm-linker-create");
    const previewEl = getEl("egm-linker-preview");
    const statusEl = getEl("egm-linker-status");
    const bodyEl = getEl("egm-linker-current-body");
    if (
      !(pathInput instanceof HTMLInputElement) ||
      !(destinationInput instanceof HTMLSelectElement) ||
      !(checkBtn instanceof HTMLButtonElement) ||
      !(createBtn instanceof HTMLButtonElement) ||
      !(previewEl instanceof HTMLElement) ||
      !(statusEl instanceof HTMLElement) ||
      !(bodyEl instanceof HTMLElement)
    ) {
      return;
    }

    let lastCheckedPath = "";
    let lastCanCreate = false;
    let savedLinks = [];

    const normalizeCampaignPath = (value) => String(value ?? "")
      .trim()
      .replace(/\\/g, "/")
      .replace(/^https?:\/\/[^/]+\/campaigns\//i, "")
      .replace(/^\/?campaigns\//i, "")
      .replace(/^\/+|\/+$/g, "")
      .replace(/\/+/g, "/");

    const setStatus = (message, isError = false) => {
      statusEl.textContent = String(message || "").trim();
      statusEl.style.color = isError ? "#d1434a" : "";
    };

    const setBusy = (busy) => {
      pathInput.disabled = busy;
      destinationInput.disabled = busy;
      checkBtn.disabled = busy;
      createBtn.disabled = busy || !lastCanCreate;
    };

    const renderLinkState = (data = null) => {
      bodyEl.replaceChildren();
      const rows = savedLinks.filter(link => !data || link.path !== data.path);
      if (data && typeof data === "object") rows.push(data);
      if (!rows.length) {
        const row = document.createElement("tr");
        const cell = document.createElement("td");
        cell.colSpan = 4;
        cell.className = "muted";
        cell.textContent = "هنوز لینکی برای این رویداد ساخته نشده است.";
        row.appendChild(cell);
        bodyEl.appendChild(row);
        return;
      }

      for (const data of rows) {
        const existing = data.existing && typeof data.existing === "object" ? data.existing : null;
        const row = document.createElement("tr");
        const campaignCell = document.createElement("td");
        const typeCell = document.createElement("td");
        const targetCell = document.createElement("td");
        const statusCell = document.createElement("td");
        const campaignUrl = String(data.campaign_url || `/campaigns/${data.path || ""}`);
        if (existing) {
          const link = document.createElement("a");
          link.href = campaignUrl;
          link.target = "_blank";
          link.rel = "noopener";
          link.textContent = campaignUrl;
          campaignCell.appendChild(link);
          typeCell.textContent = String(existing.redirect_type_label || "تغییر مسیر عادی");
          targetCell.textContent = String(existing.target || "");
          statusCell.textContent = data.owned_by_egm
            ? "ذخیره‌شده"
            : "اشغال‌شده";
        } else {
          campaignCell.textContent = campaignUrl;
          typeCell.textContent = String(data.redirect_type_label || "تغییر مسیر ثبت‌شده");
          targetCell.textContent = String(data.target || "");
          statusCell.textContent = "در دسترس";
        }
        row.append(campaignCell, typeCell, targetCell, statusCell);
        bodyEl.appendChild(row);
      }
    };

    const loadSavedLinks = async () => {
      setBusy(true);
      try {
        const payload = await requestStoreGet("list_campaign_links");
        savedLinks = Array.isArray(payload) ? payload : [];
        renderLinkState();
      } catch (error) {
        setStatus(error?.message || "دریافت لینک‌های ذخیره‌شده ناموفق بود.", true);
      } finally {
        setBusy(false);
      }
    };

    const updatePreview = () => {
      const path = normalizeCampaignPath(pathInput.value);
      previewEl.textContent = path ? `/campaigns/${path}` : "";
      lastCanCreate = false;
      createBtn.disabled = true;
      renderLinkState(null);
    };

    const checkLink = async () => {
      const path = normalizeCampaignPath(pathInput.value);
      pathInput.value = path;
      lastCheckedPath = "";
      lastCanCreate = false;
      createBtn.disabled = true;
      renderLinkState(null);
      if (!path) {
        setStatus("مسیر کمپین را وارد کنید.", true);
        return;
      }
      setBusy(true);
      setStatus("مسیر کمپین در حال بررسی است...");
      try {
        const payload = await requestStorePost("check_campaign_link", { path, destination: destinationInput.value });
        const data = payload?.data && typeof payload.data === "object" ? payload.data : {};
        renderLinkState(data);
        lastCheckedPath = String(data.path || path);
        lastCanCreate = Boolean(data.can_create);
        createBtn.disabled = !lastCanCreate;
        if (data.available) {
          setStatus(`${data.campaign_url || `/campaigns/${path}`} is available.`);
        } else if (data.owned_by_egm) {
          setStatus(`${data.campaign_url || `/campaigns/${path}`} already points to this destination.`);
        } else {
          setStatus(`${data.campaign_url || `/campaigns/${path}`} is already used by another redirect.`, true);
        }
      } catch (error) {
        renderLinkState(null);
        setStatus(error?.message || "بررسی مسیر کمپین ناموفق بود.", true);
      } finally {
        setBusy(false);
      }
    };

    const createLink = async () => {
      const path = normalizeCampaignPath(pathInput.value);
      if (!path) {
        setStatus("مسیر کمپین را وارد کنید.", true);
        return;
      }
      if (path !== lastCheckedPath || !lastCanCreate) {
        await checkLink();
        if (!lastCanCreate) return;
      }
      setBusy(true);
      setStatus("لینک کوتاه در حال ساخت است...");
      try {
        const payload = await requestStorePost("create_campaign_link", { path, destination: destinationInput.value });
        const data = payload?.data && typeof payload.data === "object" ? payload.data : {};
        if (data.owned_by_egm && data.existing) {
          savedLinks = savedLinks.filter(link => link.path !== data.path);
          savedLinks.push(data);
        }
        renderLinkState(data);
        lastCheckedPath = String(data.path || path);
        lastCanCreate = Boolean(data.can_create);
        createBtn.disabled = true;
        setStatus(payload?.message || "لینک کوتاه ساخته شد.");
        if (typeof window.showDefaultToast === "function") {
          window.showDefaultToast("لینک کوتاه ساخته شد.");
        }
      } catch (error) {
        setStatus(error?.message || "ساخت لینک کوتاه ناموفق بود.", true);
      } finally {
        setBusy(false);
      }
    };

    pathInput.addEventListener("input", updatePreview);
    destinationInput.addEventListener("change", updatePreview);
    pathInput.addEventListener("blur", () => {
      pathInput.value = normalizeCampaignPath(pathInput.value);
      updatePreview();
    });
    pathInput.addEventListener("keydown", (event) => {
      if (event.key !== "Enter") return;
      event.preventDefault();
      void checkLink();
    });
    checkBtn.addEventListener("click", () => {
      void checkLink();
    });
    createBtn.addEventListener("click", () => {
      void createLink();
    });
    updatePreview();
    void loadSavedLinks();
  }

  async function initRewardGuide(initialSettings = {}) {
    const pane = document.querySelector('.sub-pane[data-pane="egm-rewards-config"]');
    if (!(pane instanceof HTMLElement)) return;
    if (pane.dataset.rewardGuideInitialized === "1") return;
    pane.dataset.rewardGuideInitialized = "1";

    const triggers = Array.from(pane.querySelectorAll("[data-egm-reward-config-trigger]"));
    const sections = Array.from(pane.querySelectorAll("[data-egm-reward-config-section]"));
    const activate = (key) => {
      const activeKey = String(key || "guide").trim() || "guide";
      triggers.forEach((trigger) => {
        if (!(trigger instanceof HTMLElement)) return;
        const isActive = String(trigger.getAttribute("data-egm-reward-config-trigger") || "") === activeKey;
        trigger.classList.toggle("active", isActive);
        trigger.setAttribute("aria-selected", isActive ? "true" : "false");
      });
      sections.forEach((section) => {
        if (!(section instanceof HTMLElement)) return;
        section.hidden = String(section.getAttribute("data-egm-reward-config-section") || "") !== activeKey;
      });
    };
    triggers.forEach((trigger) => {
      trigger.addEventListener("click", () => {
        activate(trigger.getAttribute("data-egm-reward-config-trigger") || "guide");
      });
    });
    activate("guide");

    const titleInput = getEl("egm-reward-guide-title");
    const textInput = getEl("egm-reward-guide-text");
    if (!(titleInput instanceof HTMLInputElement) || !(textInput instanceof HTMLTextAreaElement)) {
      return;
    }
    const initialGuide = initialSettings?.rewardGuide && typeof initialSettings.rewardGuide === "object"
      ? initialSettings.rewardGuide
      : {};
    titleInput.value = String(initialGuide?.title || "راهنمای دریافت جایزه");
    textInput.value = String(initialGuide?.text || "");

    let rewardGuideDirty = false;
    [titleInput, textInput].forEach((field) => {
      field.addEventListener("input", () => {
        rewardGuideDirty = true;
        setRewardGuideStatus("");
      });
    });
    textInput.addEventListener("keydown", applyRewardGuideEditorShortcut);

    try {
      const guide = await requestStoreGet("get_reward_guide");
      if (!rewardGuideDirty) {
        titleInput.value = String(guide?.title || titleInput.value || "راهنمای دریافت جایزه");
        textInput.value = String(guide?.text || "");
      }
    } catch (error) {
      if (!rewardGuideDirty && (!initialGuide || Object.keys(initialGuide).length === 0)) {
        setRewardGuideStatus(error?.message || "بارگذاری راهنمای جایزه ناموفق بود.", true);
      }
    }
  }

  async function initRewardPrizeDisplay(initialSettings = {}) {
    const pane = document.querySelector('.sub-pane[data-pane="egm-rewards-config"]');
    if (!(pane instanceof HTMLElement)) return;
    if (pane.dataset.rewardPrizeDisplayInitialized === "1") return;
    pane.dataset.rewardPrizeDisplayInitialized = "1";

    const showPrizeToggle = getEl("egm-reward-show-prize-toggle");
    const nonValueDescribeToggle = getEl("egm-reward-non-value-describe-toggle");
    const hiddenTextInput = getEl("egm-reward-hidden-prize-text");
    if (!(showPrizeToggle instanceof HTMLInputElement) || !(hiddenTextInput instanceof HTMLInputElement)) {
      return;
    }

    const applyDisplaySettings = (raw) => {
      const settings = normalizeRewardPrizeDisplay(raw);
      if (nonValueDescribeToggle instanceof HTMLInputElement) {
        nonValueDescribeToggle.checked = Boolean(settings.nonValuePrizeDescribe);
      }
      showPrizeToggle.checked = Boolean(settings.showPrize);
      hiddenTextInput.value = settings.hiddenText;
      syncRewardAdvancedFields();
    };

    applyDisplaySettings(initialSettings?.rewardPrizeDisplay || {});
    let dirty = false;
    [nonValueDescribeToggle, showPrizeToggle, hiddenTextInput].forEach((field) => {
      if (!(field instanceof HTMLInputElement)) return;
      field.addEventListener("input", () => {
        dirty = true;
        setRewardAdvancedStatus("");
        syncRewardAdvancedFields();
      });
      field.addEventListener("change", () => {
        dirty = true;
        setRewardAdvancedStatus("");
        syncRewardAdvancedFields();
      });
    });

    try {
      const display = await requestStoreGet("get_reward_prize_display");
      if (!dirty) {
        applyDisplaySettings(display);
      }
    } catch (error) {
      if (!dirty) {
        setRewardAdvancedStatus(error?.message || "بارگذاری تنظیمات پیشرفته جوایز ناموفق بود.", true);
      }
    }
  }

  async function saveRewardPrizeDisplayFromDom(saveBtn) {
    const nonValueDescribeToggle = getEl("egm-reward-non-value-describe-toggle");
    const showPrizeToggle = getEl("egm-reward-show-prize-toggle");
    const hiddenTextInput = getEl("egm-reward-hidden-prize-text");
    if (!(showPrizeToggle instanceof HTMLInputElement) || !(hiddenTextInput instanceof HTMLInputElement)) {
      setRewardAdvancedStatus("فیلدهای تنظیمات پیشرفته جوایز یافت نشدند.", true);
      return;
    }
    const rewardPrizeDisplay = {
      nonValuePrizeDescribe: nonValueDescribeToggle instanceof HTMLInputElement
        ? Boolean(nonValueDescribeToggle.checked)
        : false,
      showPrize: Boolean(showPrizeToggle.checked),
      hiddenText: hiddenTextInput.value
    };
    if (!rewardPrizeDisplay.nonValuePrizeDescribe && !rewardPrizeDisplay.showPrize && String(rewardPrizeDisplay.hiddenText || "").trim() === "") {
      setRewardAdvancedStatus("پیش از پنهان کردن ارزش جایزه، متن جایگزین را وارد کنید.", true);
      hiddenTextInput.focus();
      return;
    }
    if (saveBtn instanceof HTMLButtonElement) {
      saveBtn.disabled = true;
    }
    setRewardAdvancedStatus("در حال ذخیره...");
    try {
      await requestStorePost("save_reward_prize_display", { rewardPrizeDisplay });
      Object.assign(settingsCache, { rewardPrizeDisplay: normalizeRewardPrizeDisplay(rewardPrizeDisplay) });
      setRewardAdvancedStatus("ذخیره شد.");
    } catch (error) {
      setRewardAdvancedStatus(error?.message || "ذخیره تنظیمات پیشرفته جوایز ناموفق بود.", true);
    } finally {
      if (saveBtn instanceof HTMLButtonElement) {
        saveBtn.disabled = false;
      }
    }
  }

  async function saveRewardGuideFromDom(saveBtn) {
    const titleInput = getEl("egm-reward-guide-title");
    const textInput = getEl("egm-reward-guide-text");
    if (!(titleInput instanceof HTMLInputElement) || !(textInput instanceof HTMLTextAreaElement)) {
      setRewardGuideStatus("فیلدهای راهنمای جایزه پیدا نشدند.", true);
      return;
    }
    if (saveBtn instanceof HTMLButtonElement) {
      saveBtn.disabled = true;
    }
    setRewardGuideStatus("در حال ذخیره...");
    try {
      const rewardGuide = {
        title: titleInput.value,
        text: textInput.value
      };
      let saveError = null;
      try {
        await requestStorePost("save_reward_guide", { rewardGuide });
      } catch (error) {
        saveError = error;
      }
      if (saveError) {
        await requestStorePost("save_settings", { settings: { rewardGuide } });
      } else {
        await saveSettings({ rewardGuide });
      }
      setRewardGuideStatus("ذخیره شد.");
    } catch (error) {
      setRewardGuideStatus(error?.message || "ذخیره راهنمای جایزه ناموفق بود.", true);
    } finally {
      if (saveBtn instanceof HTMLButtonElement) {
        saveBtn.disabled = false;
      }
    }
  }

  document.addEventListener("click", (event) => {
    const target = event.target;
    if (!(target instanceof Element)) return;
    const button = target.closest("#egm-reward-guide-save");
    if (!(button instanceof HTMLButtonElement)) return;
    event.preventDefault();
    void saveRewardGuideFromDom(button);
  });

  document.addEventListener("click", (event) => {
    const target = event.target;
    if (!(target instanceof Element)) return;
    const button = target.closest("#egm-reward-advanced-save");
    if (!(button instanceof HTMLButtonElement)) return;
    event.preventDefault();
    void saveRewardPrizeDisplayFromDom(button);
  });

  async function initSettings() {
    const saveBtn = getEl("egm-settings-save");
    const activeToggle = getEl("egm-active-toggle");
    const durationToggle = getEl("egm-duration-toggle");
    const startDate = getEl("egm-duration-start");
    const startTime = getEl("egm-duration-start-time");
    const endDate = getEl("egm-duration-end");
    const endTime = getEl("egm-duration-end-time");

    organizeControlPanel();
    initControlPanelTabs();
    initCampaignLinker();
    const settings = await loadSettings();
    applySettings(settings);
    getEl("egm-admin-passcode-save")?.addEventListener("click", async event => {
      const button = event.currentTarget;
      const status = getEl("egm-admin-passcode-status");
      const input = getEl("egm-admin-passcode");
      const confirm = getEl("egm-admin-passcode-confirm");
      const normalize = value => String(value || "").trim()
        .replace(/[۰-۹]/g, digit => String("۰۱۲۳۴۵۶۷۸۹".indexOf(digit)))
        .replace(/[٠-٩]/g, digit => String("٠١٢٣٤٥٦٧٨٩".indexOf(digit)));
      const code = normalize(input?.value);
      const confirmation = normalize(confirm?.value);
      button.disabled = true;
      if (status) status.textContent = "در حال ذخیره...";
      try {
        if (!/^\d{4,6}$/.test(code)) throw new Error("کد باید ۴ تا ۶ رقم باشد.");
        if (code !== confirmation) throw new Error("کد و تکرار آن یکسان نیستند.");
        await saveSettings({ adminPasscode: { code } });
        if (input) input.value = "";
        if (confirm) confirm.value = "";
        if (status) status.textContent = "کد با موفقیت ذخیره شد.";
        const state = getEl("egm-admin-passcode-state");
        if (state) state.textContent = "کد تنظیم شده است";
        settingsCache.adminPasscode = { ...settingsCache.adminPasscode, configured: true };
        try { localStorage.setItem("egmSettingsUpdated", String(Date.now())); } catch {}
      } catch (error) {
        if (status) status.textContent = error?.message || "ذخیره کد ناموفق بود.";
      } finally {
        button.disabled = false;
      }
    });
    getEl("egm-add-ticket-type")?.addEventListener("click", () => {
      const tickets = collectTicketTypes();
      tickets.push({ id: `ticket-${Date.now()}`, title: `بلیت ${tickets.length + 1}` });
      renderTicketTypes(tickets);
      const input = getEl("egm-ticket-types")?.querySelector("[data-ticket-type-row]:last-child [data-ticket-title]");
      if (input instanceof HTMLInputElement) input.focus();
    });
    getEl("egm-save-ticket-types")?.addEventListener("click", async event => {
      const button = event.currentTarget;
      const status = getEl("egm-ticket-types-status");
      const original = button instanceof HTMLButtonElement ? button.textContent : "";
      if (button instanceof HTMLButtonElement) {
        button.disabled = true;
        button.textContent = "در حال ذخیره...";
      }
      if (status) status.textContent = "";
      try {
        const settings = collectSettings();
        const ticketsChanged = JSON.stringify(settingsCache.customNumberTicketSettings?.tickets || []) !== JSON.stringify(settings.customNumberTicketSettings.tickets);
        await saveSettings({ printSettings: settings.printSettings, customNumberTicketSettings: settings.customNumberTicketSettings });
        settingsCache.printSettings = settings.printSettings;
        try { localStorage.setItem("egmSettingsUpdated", String(Date.now())); } catch {}
        if (ticketsChanged) await refreshTicketDesignTabs();
        settingsCache.customNumberTicketSettings = settings.customNumberTicketSettings;
        if (status) status.textContent = "تنظیمات چاپ و بلیت ذخیره شد.";
      } catch (error) {
        if (status) status.textContent = error?.message || "ذخیره تنظیمات چاپ و بلیت ناموفق بود.";
      } finally {
        if (button instanceof HTMLButtonElement) {
          button.disabled = false;
          button.textContent = original || "ذخیره چاپ و بلیت";
        }
      }
    });
    getEl("egm-ticket-types")?.addEventListener("click", event => {
      const button = event.target instanceof Element ? event.target.closest("[data-remove-ticket-type]") : null;
      if (!button) return;
      const rows = document.querySelectorAll("[data-ticket-type-row]");
      if (rows.length <= 1) return;
      button.closest("[data-ticket-type-row]")?.remove();
    });
    initAssignAdmin();
    activeToggle?.addEventListener("change", () => {
      syncToggles({ activeToggle, durationToggle });
    });
    durationToggle?.addEventListener("change", () => {
      syncToggles({ activeToggle, durationToggle });
    });
    [startDate, startTime, endDate, endTime].forEach(field => {
      field?.addEventListener("change", updateStatus);
      field?.addEventListener("input", updateStatus);
    });
    saveBtn?.addEventListener("click", async () => {
      const original = saveBtn.textContent;
      saveBtn.disabled = true;
      saveBtn.textContent = "در حال ذخیره...";
      try {
        const settings = collectSettings();
        await saveSettings({ active: settings.active, duration: settings.duration, maintenanceMode: settings.maintenanceMode, eventAccessLocked: settings.eventAccessLocked, startDate: settings.startDate, startTime: settings.startTime, endDate: settings.endDate, endTime: settings.endTime });
        saveBtn.textContent = "ذخیره شد";
        try { localStorage.setItem("egmSettingsUpdated", String(Date.now())); } catch {}
        window.setTimeout(() => { saveBtn.textContent = original; }, 1200);
      } catch (error) {
        saveBtn.textContent = error?.message || "خطا در ذخیره";
      } finally {
        saveBtn.disabled = false;
      }
    });
    updateStatus();
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", initSettings);
  } else {
    initSettings();
  }
})();


