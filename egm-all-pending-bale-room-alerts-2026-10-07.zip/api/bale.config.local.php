<?php
return [
    'bot_token' => '1202380470:j_B14qKZtIdruliSJTrWIeLJklkrJxsmBAw',
    'webhook_secret' => 'cbd051391ac86f4372102659a6fadbbe51b5a526a63dd6ed860d0c7b4d22f04a',
    'proxy_url' => '',
    'proxy_username' => '',
    'proxy_password' => '',
];
