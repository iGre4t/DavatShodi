<?php
declare(strict_types=1);
return [
    'bot_token' => '8861561411:AAG0_f4UkAlAaYB-R33KpuQuUc1TCFRljdo',
    'webhook_secret' => 'ebce1086b8325f307f3e1b9e81fb295994c68b7b4781d0faf9543d41ff4bea3e',
];
