<?php
declare(strict_types=1);

$projectRoot = realpath(__DIR__);
while (is_string($projectRoot) && !is_file($projectRoot . DIRECTORY_SEPARATOR . 'api' . DIRECTORY_SEPARATOR . 'config.php')) {
    $parent = dirname($projectRoot);
    $projectRoot = $parent === $projectRoot ? false : $parent;
}
if (!is_string($projectRoot)) {
    http_response_code(500);
    exit('Application configuration was not found.');
}
require_once $projectRoot . '/api/lib/common.php';
require_once $projectRoot . '/api/lib/users.php';
require_once $projectRoot . '/api/lib/egm-registry.php';
require_once $projectRoot . '/api/lib/egm-games.php';
require_once $projectRoot . '/api/lib/egm-refmonitor-teams.php';

// This cookie is independent of PHPSESSID (panel.php) and EGM's guest cookie.
if (session_status() !== PHP_SESSION_ACTIVE) {
    $secure = (!empty($_SERVER['HTTPS']) && strtolower((string)$_SERVER['HTTPS']) !== 'off')
        || (string)($_SERVER['SERVER_PORT'] ?? '') === '443';
    session_name('REFMONITOR' . substr(hash('sha256', (string)realpath(__DIR__)), 0, 12));
    ini_set('session.use_strict_mode', '1');
    session_set_cookie_params([
        'lifetime' => 86400,
        'path' => '/',
        'secure' => $secure,
        'httponly' => true,
        'samesite' => 'Lax',
    ]);
    session_start();
}
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('X-Content-Type-Options: nosniff');
header('Referrer-Policy: same-origin');
$nonce = base64_encode(random_bytes(16));
header("Content-Security-Policy: default-src 'self'; script-src 'self' 'nonce-{$nonce}'; style-src 'self' 'nonce-{$nonce}'; img-src 'self' data:; font-src 'self' data:; base-uri 'self'; form-action 'self'; frame-ancestors 'none'; object-src 'none'");

if (!is_string($_SESSION['ref_monitor_csrf'] ?? null) || $_SESSION['ref_monitor_csrf'] === '') {
    $_SESSION['ref_monitor_csrf'] = bin2hex(random_bytes(32));
}
$escape = static fn($value): string => htmlspecialchars((string)$value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
$config = loadConfig($projectRoot . '/api/config.php');
$pdo = connectDatabase($config);
$eventName = 'RefMonitor';
$eventCode = '';
if ($pdo instanceof PDO) {
    $relativeDirectory = str_replace('\\', '/', substr(__DIR__, strlen($projectRoot) + 1));
    try {
        $registry = findEgmRegistryByDirectory($pdo, $relativeDirectory);
        $eventName = trim((string)($registry['name'] ?? '')) ?: $eventName;
        $eventCode = trim((string)($registry['code'] ?? ''));
    } catch (Throwable $error) {
        error_log('RefMonitor event lookup failed: ' . $error->getMessage());
    }
}

$currentUser = null;
$sessionCode = trim((string)($_SESSION['ref_monitor_user_code'] ?? ''));
if ($sessionCode !== '' && $pdo instanceof PDO) {
    $user = loadUserByCode($pdo, $sessionCode);
    if (is_array($user) && userHasPermissionId($user, 'event-guest-manager')) {
        $currentUser = $user;
    } else {
        unset($_SESSION['ref_monitor_user_code']);
    }
}

$errors = [];
$username = '';
if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST') {
    $csrf = (string)($_POST['csrf'] ?? '');
    if (!hash_equals((string)$_SESSION['ref_monitor_csrf'], $csrf)) {
        http_response_code(403);
        if (in_array((string)($_POST['action'] ?? ''), ['period_status', 'search_invitees', 'create_team', 'start_team', 'list_teams', 'team_detail', 'update_name', 'update_members', 'update_cover_color', 'update_team_details', 'submit_score'], true)) {
            header('Content-Type: application/json; charset=UTF-8');
            echo json_encode(['status' => 'error', 'message' => 'فرم منقضی شده است. صفحه را تازه‌سازی کنید.'], JSON_UNESCAPED_UNICODE);
            exit;
        }
        $errors[] = 'فرم منقضی شده است. صفحه را تازه‌سازی کنید.';
    } elseif (($_POST['action'] ?? '') === 'logout') {
        $_SESSION = [];
        if (ini_get('session.use_cookies')) {
            $cookie = session_get_cookie_params();
            setcookie(session_name(), '', time() - 42000, $cookie['path'] ?? '/', $cookie['domain'] ?? '', (bool)($cookie['secure'] ?? false), (bool)($cookie['httponly'] ?? true));
        }
        session_destroy();
        header('Location: RefMonitor.php');
        exit;
    } elseif (($_POST['action'] ?? '') === 'login') {
        $username = trim((string)($_POST['username'] ?? ''));
        $password = trim((string)($_POST['password'] ?? ''));
        $attempts = array_values(array_filter((array)($_SESSION['ref_monitor_failures'] ?? []),
            static fn($time): bool => is_int($time) && $time > time() - 600));
        if (count($attempts) >= 5) {
            http_response_code(429);
            $errors[] = 'تلاش‌های زیادی انجام شده است. چند دقیقه دیگر دوباره امتحان کنید.';
        } elseif (!$pdo instanceof PDO) {
            http_response_code(503);
            $errors[] = 'اتصال به پایگاه داده برقرار نشد.';
        } elseif ($username === '' || $password === '') {
            $errors[] = 'نام کاربری و رمز عبور الزامی است.';
        } else {
            try {
                $select = '`code`, `username`, `fullname`, `password_hash`';
                if (usersTableHasColumn($pdo, 'permissions')) $select .= ', `permissions`';
                $statement = $pdo->prepare("SELECT {$select} FROM `users` WHERE `username` = :username LIMIT 1");
                $statement->execute([':username' => $username]);
                $user = $statement->fetch(PDO::FETCH_ASSOC);
                if (is_array($user)
                    && password_verify($password, (string)($user['password_hash'] ?? ''))
                    && userHasPermissionId($user, 'event-guest-manager')) {
                    session_regenerate_id(true);
                    $_SESSION['ref_monitor_user_code'] = (string)$user['code'];
                    $_SESSION['ref_monitor_csrf'] = bin2hex(random_bytes(32));
                    unset($_SESSION['ref_monitor_failures']);
                    header('Location: RefMonitor.php');
                    exit;
                }
                $errors[] = 'نام کاربری، رمز عبور یا دسترسی EGM معتبر نیست.';
            } catch (Throwable $error) {
                error_log('RefMonitor login failed: ' . $error->getMessage());
                http_response_code(503);
                $errors[] = 'بررسی حساب کاربری ناموفق بود.';
            }
        }
        if ($errors !== []) {
            $attempts[] = time();
            $_SESSION['ref_monitor_failures'] = $attempts;
        }
    } elseif (in_array((string)($_POST['action'] ?? ''), ['period_status', 'search_invitees', 'create_team', 'start_team', 'list_teams', 'team_detail', 'update_name', 'update_members', 'update_cover_color', 'update_team_details', 'submit_score'], true)) {
        header('Content-Type: application/json; charset=UTF-8');
        if (!$currentUser || !$pdo instanceof PDO || $eventCode === '') {
            http_response_code(403);
            echo json_encode(['status' => 'error', 'message' => 'دسترسی معتبر نیست. دوباره وارد شوید.'], JSON_UNESCAPED_UNICODE);
            exit;
        }
        try {
            if (($_POST['action'] ?? '') === 'period_status') {
                try {
                    $period = egmRefMonitorActivePeriod($pdo, $eventCode);
                } catch (InvalidArgumentException $error) {
                    $period = null;
                }
                echo json_encode(['status' => 'ok', 'period_code' => $period['code'] ?? ''], JSON_UNESCAPED_UNICODE);
                exit;
            }
            $activePeriod = egmRefMonitorActivePeriod($pdo, $eventCode);
            $periodCode = $activePeriod['code'];
            if (trim((string)($_POST['period_code'] ?? '')) !== $periodCode) {
                throw new InvalidArgumentException('بازهٔ فعال تغییر کرده است. صفحه را تازه‌سازی کنید.');
            }
            $gameId = trim((string)($_POST['game_id'] ?? ''));
            egmRefMonitorGameTable($pdo, $eventCode, $periodCode, $gameId);
            $action = (string)$_POST['action'];
            $teamId = (int)($_POST['team_id'] ?? 0);
            if ($action === 'search_invitees') {
                $result = ['invitees' => egmRefMonitorSearchInvitees($pdo, $eventCode, $periodCode, (string)($_POST['query'] ?? ''))];
            } elseif ($action === 'create_team') {
                $members = $_POST['members'] ?? [];
                if (!is_array($members)) throw new InvalidArgumentException('اعضای تیم معتبر نیستند.');
                if (!is_string($_POST['cover_color'] ?? '')) throw new InvalidArgumentException('رنگ پوشش معتبر نیست.');
                $result = ['team' => egmRefMonitorCreateTeam($pdo, $eventCode, $periodCode, $gameId, (string)($_POST['name'] ?? ''), $members, (string)$currentUser['code'], is_string($_POST['cover_color'] ?? '') ? ($_POST['cover_color'] ?? '') : '')];
            } elseif ($action === 'start_team') {
                $result = ['team' => egmRefMonitorStartTeam($pdo, $eventCode, $periodCode, $gameId, $teamId, (string)$currentUser['code'])];
            } elseif ($action === 'team_detail') {
                $result = ['team' => egmRefMonitorGetTeam($pdo, $eventCode, $periodCode, $gameId, $teamId)];
            } elseif ($action === 'update_name') {
                $result = ['team' => egmRefMonitorUpdateName($pdo, $eventCode, $periodCode, $gameId, $teamId, (string)($_POST['name'] ?? ''))];
            } elseif ($action === 'update_members') {
                $members = $_POST['members'] ?? [];
                if (!is_array($members)) throw new InvalidArgumentException('اعضای تیم معتبر نیستند.');
                $result = ['team' => egmRefMonitorUpdateMembers($pdo, $eventCode, $periodCode, $gameId, $teamId, $members)];
            } elseif ($action === 'update_team_details') {
                if (!is_string($_POST['name'] ?? null) || !is_string($_POST['cover_color'] ?? null)) throw new InvalidArgumentException('مشخصات تیم معتبر نیست.');
                $result = ['team' => egmRefMonitorUpdateDetails($pdo, $eventCode, $periodCode, $gameId, $teamId, $_POST['name'], $_POST['cover_color'])];
            } elseif ($action === 'update_cover_color') {
                if (!is_string($_POST['cover_color'] ?? null)) throw new InvalidArgumentException('رنگ پوشش معتبر نیست.');
                $result = ['team' => egmRefMonitorUpdateCoverColor($pdo, $eventCode, $periodCode, $gameId, $teamId, $_POST['cover_color'])];
            } elseif ($action === 'submit_score') {
                $result = ['team' => egmRefMonitorSubmitScore($pdo, $eventCode, $periodCode, $gameId, $teamId, (string)($_POST['level_id'] ?? ''), (string)($_POST['score'] ?? ''), (string)$currentUser['code'])];
            } else {
                $result = ['teams' => egmRefMonitorListTeams($pdo, $eventCode, $periodCode, $gameId)];
            }
            echo json_encode(['status' => 'ok'] + $result, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        } catch (InvalidArgumentException $error) {
            http_response_code(422);
            echo json_encode(['status' => 'error', 'message' => $error->getMessage()], JSON_UNESCAPED_UNICODE);
        } catch (Throwable $error) {
            error_log('RefMonitor team request failed: ' . $error->getMessage());
            http_response_code(500);
            echo json_encode(['status' => 'error', 'message' => 'درخواست انجام نشد. دوباره تلاش کنید.'], JSON_UNESCAPED_UNICODE);
        }
        exit;
    } else {
        http_response_code(400);
        $errors[] = 'درخواست نامعتبر است.';
    }
}
$displayName = trim((string)($currentUser['fullname'] ?? $currentUser['username'] ?? 'مدیر'));
$games = [];
$activePeriod = null;
$gamesError = '';
if ($currentUser) {
    if ($pdo instanceof PDO && $eventCode !== '') {
        try {
            $activePeriod = egmRefMonitorActivePeriod($pdo, $eventCode);
            $gameState = egmGamesState(['pdo' => $pdo, 'code' => $eventCode]);
            $enabledIds = $gameState['enabled'][$activePeriod['code']] ?? [];
            $games = array_values(array_filter($gameState['games'], static fn(array $game): bool => in_array($game['id'], $enabledIds, true)));
        } catch (InvalidArgumentException $error) {
            $gamesError = $error->getMessage();
        } catch (Throwable $error) {
            error_log('RefMonitor games lookup failed: ' . $error->getMessage());
            $gamesError = 'فهرست بازی‌ها در دسترس نیست. صفحه را دوباره بارگذاری کنید.';
        }
    } else {
        $gamesError = 'فهرست بازی‌ها در دسترس نیست.';
    }
}
?>
<!doctype html>
<html lang="fa" dir="rtl">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
  <title><?= $escape($eventName) ?> · پنل داور</title>
  <style nonce="<?= $escape($nonce) ?>">
    @font-face{font-family:Peyda;src:url('../../style/fonts/PeydaWebFaNum-Regular.woff2') format('woff2');font-display:swap;font-weight:400}
    @font-face{font-family:Peyda;src:url('../../style/fonts/PeydaWebFaNum-Bold.woff2') format('woff2');font-display:swap;font-weight:700}
    :root{--ink:#202329;--muted:#646971;--line:#e7e8eb;--surface:#fff;--shadow:0 4px 18px rgba(20,24,33,.05);--focus:0 0 0 4px rgba(65,105,190,.1)}
    *{box-sizing:border-box}body{margin:0;min-height:100vh;display:grid;place-items:center;padding:18px;direction:rtl;text-align:right;font-family:Peyda,Tahoma,Arial,sans-serif;color:var(--ink);background:#f4f4f6}button,input{font:inherit}button{cursor:pointer}button:disabled{cursor:not-allowed;opacity:.45}.hidden{display:none!important}
    .app{width:min(460px,100%)}.phone{height:calc(100dvh - 36px);min-height:min(860px,calc(100dvh - 36px));display:flex;flex-direction:column;overflow:hidden;background:#fff;border:1px solid var(--line);border-radius:26px;box-shadow:0 24px 70px rgba(20,24,33,.09),0 2px 7px rgba(20,24,33,.03)}
    .topbar{display:flex;align-items:center;justify-content:space-between;gap:12px;padding:18px 22px;border-bottom:1px solid #f0f0f2;background:#fff}.brand{font-size:.91rem;font-weight:700;color:var(--ink)}.topbar-actions{display:flex;gap:8px}.topbar button{border:0;background:none;color:var(--muted);padding:5px;font-size:.85rem}.topbar form{margin:0}
    .login-area,.main-area{flex:1;min-height:0;overflow-y:auto;padding:24px 22px calc(20px + env(safe-area-inset-bottom,0px));display:flex;flex-direction:column;gap:18px;animation:view-in .22s ease-out}.main-area h1{font-size:1.35rem;line-height:1.5;margin:0;letter-spacing:-.02em}.login-hero{text-align:center;display:grid;justify-items:center;gap:12px}.login-icon{width:76px;height:76px;display:grid;place-items:center;border-radius:22px;background:#f5f5f7;color:var(--ink);font-size:1.6rem;font-weight:700}.login-title{margin:0;font-size:1.2rem}.login-subtitle{margin:0;font-size:.88rem;color:var(--muted)}.login-form,.stack{display:flex;flex-direction:column;gap:14px}
    .login-field{display:grid;gap:8px;font-size:.86rem;font-weight:700;color:#444950}.login-input{width:100%;min-width:0;border:1px solid #dedfe3;border-radius:12px;padding:12px 14px;font-size:1rem;background:#fff;color:var(--ink);outline:none;transition:border-color .18s,box-shadow .18s}.login-input::placeholder{color:#878b92;font-weight:400}.login-input:focus{border-color:#8998b5;box-shadow:var(--focus)}.password-wrap{position:relative}.password-wrap .login-input{padding-left:46px}.password-toggle{position:absolute;left:6px;top:50%;transform:translateY(-50%);border:0;background:none;color:var(--muted);width:34px;height:34px}
    .primary-action,.login-btn,.secondary-action{border-radius:13px;padding:13px 16px;font-weight:700;font-size:.95rem;transition:transform .16s,box-shadow .18s,background .18s}.primary-action,.login-btn{border:1px solid #24272d;background:#24272d;color:#fff;box-shadow:0 5px 16px rgba(20,24,33,.14)}.primary-action:hover:not(:disabled),.login-btn:hover{background:#343941;box-shadow:0 6px 22px rgba(20,24,33,.21)}.primary-action:active:not(:disabled),.secondary-action:active{transform:scale(.985)}.secondary-action{border:1px solid var(--line);background:#fff;color:#444950;box-shadow:0 2px 4px rgba(20,24,33,.025)}.secondary-action:hover{background:#f7f7f8}.login-hint{margin:0;min-height:1.2em;color:#ab343f;font-size:.82rem;text-align:center}.login-help-card,.placeholder{padding:16px;border:1px solid var(--line);border-radius:14px;background:#fff}.login-help-card p{margin:0;color:var(--muted);font-size:.81rem;line-height:1.9}
    .games-section{display:grid;gap:12px}.games-heading,.section-label{margin:0;color:#41464e;font-size:.93rem;font-weight:700}.games-list,.team-list,.result-list,.selected-list{list-style:none;margin:0;padding:0;display:grid;gap:10px}.game-card{display:flex;align-items:center;gap:12px;min-height:72px;padding:16px;border:1px solid var(--line);border-radius:16px;background:#fff;color:var(--ink);font-weight:700;box-shadow:var(--shadow)}button.game-card,button.team-card{width:100%;font:inherit;text-align:right;color:var(--ink);transition:border-color .18s,box-shadow .18s,transform .18s}button.game-card:hover,button.team-card:hover{border-color:#c9ccd3;box-shadow:0 7px 24px rgba(20,24,33,.08);transform:translateY(-1px)}.game-icon{width:36px;height:36px;flex:none;display:grid;place-items:center;border-radius:10px;background:#f5f5f7;color:#555b65;font-size:1.2rem}.game-arrow{margin-right:auto;color:#828790}
    .team-card,.person-card{padding:15px;border:1px solid var(--line);border-radius:14px;background:#fff;box-shadow:var(--shadow)}.team-card strong,.person-card strong{display:block;color:var(--ink);font-weight:700;font-size:1rem;overflow-wrap:anywhere}.team-card small,.person-card small{display:block;color:var(--muted);font-size:.8rem;line-height:1.8}.person-card{display:flex;align-items:center;justify-content:space-between;gap:12px}.person-card>span{min-width:0;overflow-wrap:anywhere}.person-card button{flex:none;font-size:.8rem;padding:8px 11px;box-shadow:none}.selected-list .person-card{border-color:#cfd2d8}.status-text{margin:0;color:var(--muted);font-size:.83rem;line-height:1.85}.status-text:empty{display:none}.status-text.error{color:#ab343f}.status-text.success{color:#41464e}
    .team-group{list-style:none;display:grid;gap:10px}.team-group-title{margin:12px 0 0;color:#777c85;font-size:.82rem;font-weight:700}.team-state{display:none!important}.team-room-name{display:block;margin-top:8px;font-size:1.12rem;font-weight:700;overflow-wrap:anywhere}.team-room-name::before{content:'اتاق فعلی · ';font-size:.78rem;font-weight:400;color:var(--muted)}
    .team-title-row,.section-heading-row{display:flex;align-items:center;justify-content:space-between;gap:10px}.team-title-row{justify-content:flex-start}.flow-intro{display:grid;gap:6px}.flow-intro h2{margin:0;font-size:1rem}.flow-intro p{margin:0;font-size:.83rem;color:var(--muted);line-height:1.8}.team-name-form{display:flex;gap:8px;align-items:center}.team-name-form .login-input{flex:1;min-width:0}.icon-action{width:34px;height:34px;flex:none;border:1px solid var(--line);border-radius:10px;background:#fff;color:#626873;font-size:1.15rem}.inline-action{border:0;background:none;padding:5px 0;color:#525d70;font-size:.84rem;font-weight:700}.game-context{margin:0;max-width:100%;color:var(--muted);font-size:.84rem;overflow-wrap:anywhere}.team-total-score{align-self:flex-start;font-size:.84rem;color:var(--muted);font-weight:400}
    .room-guidance{display:grid;gap:10px;padding:28px 18px;border:1px solid #e0e1e5;border-radius:20px;background:#fff;text-align:center;box-shadow:0 12px 34px rgba(20,24,33,.07),0 1px 3px rgba(20,24,33,.03);scroll-margin-top:16px}.room-instruction{margin:0;font-size:.88rem;color:var(--muted);line-height:1.8}.room-guidance .room-name{margin:0;font-size:clamp(2.1rem,9vw,3.3rem);font-weight:700;line-height:1.35;letter-spacing:-.035em;color:#202329;overflow-wrap:anywhere}.room-stage{margin:0;color:#7b8088;font-size:.8rem;line-height:1.8}.room-score-hint{margin:8px 0 0;font-size:.83rem;color:#646971;line-height:1.85}.room-guidance.waiting{box-shadow:var(--shadow)}.room-guidance.waiting .room-name{font-size:1.65rem}.room-guidance.waiting .room-instruction::before{content:'';display:inline-block;width:6px;height:6px;margin-inline-end:8px;border-radius:50%;background:#8d929b;animation:waiting-pulse 1.8s ease-in-out infinite}.room-guidance.room-arrived{animation:room-arrival .65s ease-out}
    .member-section{border-top:1px solid var(--line);padding-top:16px}.member-section>summary{display:flex;align-items:center;justify-content:space-between;cursor:pointer;list-style:none;color:#41464e;font-size:.9rem;font-weight:700;padding:6px 0}.member-section>summary::-webkit-details-marker{display:none}.member-section>summary::after{content:'+';color:#8d929b;font-size:1.1rem}.member-section[open]>summary::after{content:'−'}.member-section .inline-action{margin:6px 0 8px}.detail-members{list-style:none;margin:0;padding:0;counter-reset:member;display:grid;gap:0}.detail-members li{counter-increment:member;display:flex;align-items:center;gap:12px;padding:13px 0;border-bottom:1px solid #f0f0f2;background:#fff}.detail-members li:last-child{border-bottom:0}.detail-members li::before{content:counter(member);display:grid;place-items:center;flex:none;width:32px;height:32px;border:1px solid #ebecf0;border-radius:50%;color:#6c727d;background:#fafafa;font-size:.85rem}.member-info{display:grid;gap:3px;min-width:0}.member-name{font-size:.97rem;font-weight:700;overflow-wrap:anywhere}.member-code{font-size:.76rem;color:#858a93;overflow-wrap:anywhere}.review-members{list-style:none;padding:0;margin:0;display:grid;gap:0}.review-members li{padding:12px 0;border-bottom:1px solid #eee;color:#41464e;font-size:.94rem;overflow-wrap:anywhere}.review-members li:last-child{border:0}
    .flow-panel{display:grid;gap:18px}.flow-card,.detail-card{display:grid;gap:14px;padding:18px;border:1px solid var(--line);border-radius:16px;background:#fff;box-shadow:var(--shadow)}.flow-card h2{margin:0;font-size:1rem;color:var(--ink)}.step-track{height:3px;border-radius:10px;background:#eee;overflow:hidden}.step-track span{display:block;height:100%;width:33.33%;background:#606773;transition:width .25s}.step-indicator{margin:0;font-size:.77rem;color:#858a93}.action-dock{position:sticky;bottom:-1px;z-index:5;flex:none;margin-top:auto;padding:14px 0 max(12px,env(safe-area-inset-bottom,0px));background:linear-gradient(to bottom,rgba(255,255,255,.94),#fff 22%)}.flow-action{width:100%;margin:0}.action-dock .status-text{margin-top:8px}
    .score-context{position:sticky;top:-24px;z-index:2;background:rgba(255,255,255,.96);backdrop-filter:blur(12px);padding:14px 0;border-bottom:1px solid var(--line)}.score-context h1{font-size:1.3rem}.score-context #ref-score-team{font-size:.86rem;color:#5f6570}.score-form{display:grid;gap:14px}.score-number{font-size:2rem;font-weight:700;text-align:center;padding:18px;background:#fff}.score-number::placeholder{font-size:.96rem;font-weight:400}.score-help{margin:0;color:var(--muted);font-size:.82rem;line-height:1.9}.score-calculation summary{cursor:pointer;color:#777c85;font-size:.8rem}.score-calculation[open] summary{margin-bottom:8px}.progress-list{list-style:none;padding:0;margin:0;display:grid;gap:10px}.progress-list li{display:flex;align-items:center;justify-content:space-between;gap:12px;padding:14px;border:1px solid var(--line);border-radius:12px;background:#fff;color:#545b65;font-size:.87rem}
    .completion-card{display:grid;gap:14px;padding:26px 18px;border:1px solid var(--line);border-radius:20px;background:#fff;box-shadow:var(--shadow);text-align:center;scroll-margin-top:16px}.completion-card h2{margin:0;font-size:1.05rem;color:#4d545e}.completion-card strong{font-size:1.85rem;color:var(--ink)}.completion-card p{margin:0;font-size:.84rem;color:var(--muted);line-height:1.9}
    .cover-picker{display:grid;gap:12px;padding:0;border:0;background:#fff}.cover-detail{display:grid;gap:10px;padding:0;border:0;background:#fff}.cover-detail strong{font-size:.84rem;font-weight:400;color:#646971;overflow-wrap:anywhere}.cover-choices{display:flex;flex-wrap:wrap;gap:8px}.cover-choice{display:flex;align-items:center;gap:7px;padding:9px 11px;min-height:42px;border:1px solid var(--line);border-radius:10px;background:#fff;color:#545b65;font-size:.84rem;transition:border-color .18s,box-shadow .18s}.cover-choice[aria-pressed="true"]{border-color:#7d8490;box-shadow:0 0 0 2px rgba(50,60,78,.08)}.cover-swatch{width:14px;height:14px;flex:none;border:1px solid rgba(0,0,0,.16);border-radius:50%}.required-note{font-size:.72rem;font-weight:400;color:#888d96;margin-inline-start:5px}.cover-badge{display:block;width:fit-content;max-width:100%;margin:6px 0 0;font-size:.79rem;font-weight:400;color:#707681;overflow-wrap:anywhere}.cover-swatch[data-color="آبی"]{background:#357be2}.cover-swatch[data-color="قرمز"]{background:#d94b55}.cover-swatch[data-color="سبز"]{background:#3f9474}.cover-swatch[data-color="زرد"]{background:#e1b939}.cover-swatch[data-color="نارنجی"]{background:#e58b37}.cover-swatch[data-color="بنفش"]{background:#8a63bb}.cover-swatch[data-color="مشکی"]{background:#303642}.cover-swatch[data-color="سفید"]{background:#fff}
    .score-confirm{width:min(420px,calc(100% - 28px));max-height:calc(100dvh - 40px);overflow:auto;border:1px solid var(--line);border-radius:22px;padding:26px;color:var(--ink);background:#fff;font:inherit;text-align:right;box-shadow:0 30px 80px rgba(0,0,0,.18)}.score-confirm[open]{animation:view-in .2s ease-out}.score-confirm::backdrop{background:rgba(25,28,34,.35);backdrop-filter:blur(5px)}.score-confirm form{display:grid;gap:16px}.score-confirm h2,.score-confirm p{margin:0;line-height:1.85}.score-confirm h2{font-size:1.2rem}.score-confirm p{color:#646971;font-size:.9rem}.score-confirm strong{font-size:2rem;padding:20px 0;border-top:1px solid var(--line);border-bottom:1px solid var(--line);text-align:center}.score-confirm #ref-confirm-warning{font-size:.82rem}.confirm-actions{display:grid;gap:9px}
    button:focus-visible,summary:focus-visible{outline:3px solid #8796b0;outline-offset:3px}.quiet-details{border-top:1px solid var(--line);padding-top:12px}.quiet-details summary{cursor:pointer;color:var(--muted);font-size:.84rem}.quiet-details[open] summary{margin-bottom:12px}
    @keyframes view-in{from{opacity:0;transform:translateY(7px)}to{opacity:1;transform:translateY(0)}}@keyframes waiting-pulse{0%,100%{opacity:.35}50%{opacity:1}}@keyframes room-arrival{from{box-shadow:0 0 0 5px rgba(60,75,100,.12),0 12px 34px rgba(20,24,33,.07)}to{box-shadow:0 12px 34px rgba(20,24,33,.07)}}
    [data-ref-view="team-detail"]{gap:14px;padding-top:18px}.team-title-row{justify-content:space-between;gap:12px}.team-title-row h1{font-size:1.2rem;min-width:0;overflow-wrap:anywhere;line-height:1.5}.team-meta{display:flex;align-items:center;flex-wrap:wrap;gap:5px 12px;color:#747983;font-size:.78rem}.team-meta>*{margin:0;font-size:inherit}.team-meta #ref-detail-cover{font-weight:400;font-size:.78rem;color:#747983}.team-meta .status-text{font-size:.78rem}.room-guidance{padding:16px;gap:5px;border-radius:16px;box-shadow:0 5px 20px rgba(20,24,33,.055)}.room-guidance .room-name{font-size:2rem;line-height:1.25;letter-spacing:-.025em}.room-instruction{font-size:.76rem}.room-stage{font-size:.75rem}.room-guidance.waiting .room-name{font-size:1.35rem}.member-section{padding-top:10px}.member-section>summary{font-size:.84rem;padding:4px 0}.detail-members{max-height:144px;overflow-y:auto;margin-top:8px;scrollbar-width:thin}.detail-members li{padding:9px 0;gap:10px}.member-name{font-size:.88rem}.member-code{font-size:.73rem}.detail-members li::before{width:28px;height:28px;font-size:.77rem}.completion-card{padding:18px;gap:10px}.completion-card h2{font-size:.94rem}.completion-card p{display:none}#ref-team-edit .login-input{font-size:.94rem}#ref-team-edit #ref-edit-members{font-size:.84rem;padding:10px}#ref-team-edit #ref-member-hint{font-size:.75rem}
    @media(max-width:440px){body{padding:8px}.phone{height:calc(100dvh - 16px);min-height:calc(100dvh - 16px);border-radius:22px}.topbar{padding:16px 18px}.login-area,.main-area{padding:20px 18px calc(16px + env(safe-area-inset-bottom,0px))}.score-context{top:-20px}}
    @media(prefers-reduced-motion:reduce){*,*::before,*::after{animation:none!important;transition:none!important;scroll-behavior:auto!important}}
  </style>
</head>
<body>
<main class="app"><section class="phone">
  <header class="topbar"><div class="brand">پنل داور</div><div class="topbar-actions">
    <?php if ($currentUser): ?>
      <button type="button" id="ref-back" class="hidden">برگشت</button>
      <form method="post" id="ref-logout-form"><input type="hidden" name="csrf" value="<?= $escape($_SESSION['ref_monitor_csrf']) ?>"><input type="hidden" name="action" value="logout"><button type="submit">خروج</button></form>
    <?php endif; ?>
  </div></header>
  <?php if (!$currentUser): ?>
    <div class="login-area"><div class="login-hero"><div class="login-icon" aria-hidden="true">داور</div><h1 class="login-title"><?= $escape($eventName) ?></h1><p class="login-subtitle">ورود به پنل داور</p></div>
      <form class="login-form" method="post" autocomplete="on"><input type="hidden" name="action" value="login"><input type="hidden" name="csrf" value="<?= $escape($_SESSION['ref_monitor_csrf']) ?>">
        <label class="login-field"><span>نام کاربری</span><input class="login-input" name="username" autocomplete="username" value="<?= $escape($username) ?>" required></label>
        <label class="login-field"><span>رمز عبور</span><span class="password-wrap"><input class="login-input" id="ref-password" name="password" type="password" autocomplete="current-password" required><button class="password-toggle" id="ref-password-toggle" type="button" aria-label="نمایش رمز عبور">◉</button></span></label>
        <button class="login-btn" type="submit">ورود</button><p class="login-hint" role="alert"><?= $escape(implode(' ', $errors)) ?></p>
      </form><div class="login-help-card"><p>با نام کاربری و رمز عبور پنل مدیریت وارد شوید. ورود پنل داور مستقل از ورود پنل اصلی است.</p></div>
    </div>
  <?php else: ?>
    <div class="main-area" data-ref-view="home"><h1><?= $escape($displayName) ?> عزیز، خوش آمدید</h1>
      <?php if ($activePeriod): ?><p class="status-text">بازهٔ فعال: <?= $escape($activePeriod['title']) ?></p><?php endif; ?>
      <section class="games-section" aria-labelledby="games-heading"><h2 id="games-heading" class="games-heading">بازی‌ها</h2>
        <?php if ($gamesError !== ''): ?><div class="placeholder" role="alert"><?= $escape($gamesError) ?></div>
        <?php elseif ($games === []): ?><div class="placeholder">در این بازه بازی فعالی وجود ندارد.</div>
        <?php else: ?><ul class="games-list">
          <?php foreach ($games as $game): ?><li><button type="button" class="game-card" data-open-game="<?= $escape($game['id']) ?>"><span class="game-icon" aria-hidden="true">♟</span><span><?= $escape($game['name']) ?></span><span class="game-arrow" aria-hidden="true">‹</span></button></li><?php endforeach; ?>
        </ul><?php endif; ?>
      </section>
    </div>
    <div class="main-area hidden" data-ref-view="game"><h1 id="ref-game-title"></h1>
      <p class="status-text" id="ref-game-period"></p>
      <section class="games-section"><h2 class="games-heading">تیم‌های ثبت‌شده</h2><label class="login-field"><span>جستجوی تیم یا عضو</span><input class="login-input" type="search" id="ref-team-filter" placeholder="نام تیم، نام عضو یا کد پرسنلی"></label><p class="status-text" id="ref-teams-status" role="status"></p><ul class="team-list" id="ref-teams-list"></ul></section>
      <div class="action-dock"><button type="button" class="primary-action flow-action" id="ref-new-team">تشکیل تیم</button></div>
    </div>
    <div class="main-area hidden" data-ref-view="team"><h1 id="ref-team-form-title">تشکیل تیم</h1><p class="status-text" id="ref-team-context"></p>
      <div class="step-track" aria-hidden="true"><span id="ref-step-fill"></span></div><p class="step-indicator" id="ref-step-label"></p>
      <section class="flow-panel" data-team-step="name">
        <label class="login-field"><span>نام تیم</span><input class="login-input" id="ref-team-name" maxlength="100" autocomplete="off" required></label><section class="cover-picker hidden" id="ref-cover-picker"><label class="login-field"><span>رنگ پوشش تیم</span><select class="login-input" id="ref-team-cover-color"><option value="">انتخاب رنگ</option></select></label></section></section>
      <section class="flow-panel hidden" data-team-step="members">
        <label class="login-field"><span>جستجوی عضو</span><input class="login-input" id="ref-search-input" autocomplete="off" placeholder="نام، کد ملی یا کد پرسنلی"></label>
        <p class="status-text" id="ref-search-status" role="status"></p><ul class="result-list" id="ref-search-results"></ul>
        <div class="flow-card hidden" id="ref-selected-card"><h2>اعضا <span id="ref-member-count">(۰)</span></h2><ul class="selected-list" id="ref-selected-list"></ul></div></section>
      <section class="flow-panel hidden" data-team-step="review">
        <div class="flow-card"><h2 id="ref-review-name"></h2><p class="cover-badge hidden" id="ref-review-cover"></p><p class="status-text" id="ref-review-count"></p><ol class="review-members" id="ref-review-members"></ol></div></section>
      <div class="action-dock" data-team-action="name"><button type="button" class="primary-action flow-action" id="ref-team-next-name">ادامه</button></div>
      <div class="action-dock hidden" data-team-action="members"><button type="button" class="primary-action flow-action" id="ref-team-next-members" disabled>ادامه</button></div>
      <div class="action-dock hidden" data-team-action="review"><button type="button" class="primary-action flow-action" id="ref-submit-team">ثبت تیم</button><p class="status-text" id="ref-submit-status" role="status"></p></div>
    </div>
    <div class="main-area hidden" data-ref-view="team-detail"><div class="flow-intro"><div class="team-title-row"><h1 id="ref-detail-title"></h1><button class="icon-action" type="button" id="ref-edit-name" aria-label="ویرایش تیم" title="ویرایش تیم">✎</button></div>
      </div><div class="team-meta"><p class="status-text" id="ref-detail-state"></p><p class="game-context status-text" id="ref-detail-overview"></p><span class="hidden" id="ref-cover-detail"><strong id="ref-detail-cover"></strong></span></div><section class="room-guidance hidden" id="ref-room-card" aria-live="polite" aria-atomic="true"></section><strong class="team-total-score hidden" id="ref-total-score"></strong>
      <p class="status-text" id="ref-journey-status" role="status" aria-live="polite"></p><section class="completion-card hidden" id="ref-completion-card"><h2>بازی این تیم پایان یافت</h2><strong id="ref-completion-score"></strong><p>امتیازها ثبت شدند. می‌توانید به فهرست تیم‌ها برگردید.</p><button type="button" class="secondary-action" id="ref-completion-back">بازگشت به تیم‌ها</button></section><p class="status-text" id="ref-start-hint" role="status"></p>
      <details class="member-section" id="ref-member-section"><summary id="ref-detail-members-title">اعضای تیم</summary><ul class="detail-members" id="ref-detail-members"></ul></details><p class="status-text" id="ref-score-status" role="status"></p>
      <div class="action-dock" id="ref-detail-dock"><button class="primary-action flow-action hidden" type="button" id="ref-start-team">شروع بازی</button><button class="primary-action flow-action hidden" type="button" id="ref-open-scores">ثبت امتیاز</button></div>
    </div>
    <div class="main-area hidden" data-ref-view="score"><div class="flow-intro"><h1>ثبت امتیاز</h1><p class="status-text" id="ref-levels-team"></p></div><ul class="progress-list" id="ref-score-levels"></ul><p class="status-text" id="ref-levels-status" role="status"></p></div>
    <div class="main-area hidden" data-ref-view="score-entry"><div class="flow-intro score-context"><p class="step-indicator" id="ref-score-progress"></p><h1 id="ref-score-title">مرحله بازی</h1><p class="status-text" id="ref-score-team"></p></div>
      <div class="step-track" id="ref-score-track" aria-hidden="true"><span id="ref-score-fill"></span></div>
      <div class="flow-card" id="ref-score-stage"></div><p class="status-text" id="ref-score-step-status" role="status"></p>
      <div class="action-dock" id="ref-score-dock"><button class="primary-action flow-action" type="submit" form="ref-score-form" id="ref-score-submit">ثبت امتیاز و ادامه</button></div>
      <div class="action-dock hidden" id="ref-score-home-dock"><button class="primary-action flow-action" type="button" id="ref-score-home">بازگشت به خانه</button></div>
    </div>
  <?php endif; ?>
</section></main>
<dialog id="ref-team-edit" class="score-confirm" aria-labelledby="ref-team-edit-title"><form id="ref-team-edit-form"><h2 id="ref-team-edit-title">ویرایش تیم</h2><label class="login-field"><span>نام تیم</span><input class="login-input" id="ref-detail-name" maxlength="100" required></label><label class="login-field" id="ref-edit-color-field"><span>رنگ پوشش</span><select class="login-input" id="ref-detail-cover-input"></select></label><button class="secondary-action hidden" type="button" id="ref-edit-members">ویرایش اعضا</button><p class="status-text" id="ref-member-hint"></p><p class="status-text" id="ref-edit-status" role="status"></p><div class="confirm-actions"><button type="submit" class="primary-action" id="ref-edit-save">ذخیره تغییرات</button><button type="button" class="secondary-action" id="ref-edit-cancel">لغو</button></div></form></dialog>
<dialog id="ref-score-confirm" class="score-confirm" aria-labelledby="ref-confirm-title" aria-describedby="ref-confirm-warning"><form method="dialog"><h2 id="ref-confirm-title">تأیید امتیاز</h2><p id="ref-confirm-team"></p><p id="ref-confirm-room"></p><strong id="ref-confirm-score"></strong><p id="ref-confirm-warning">پس از ثبت، این امتیاز قابل تغییر نیست. نام تیم، اتاق و مجموع امتیاز را بررسی کنید.</p><p class="status-text error" id="ref-confirm-status" role="alert"></p><div class="confirm-actions"><button type="button" class="primary-action" id="ref-confirm-save">تأیید و ثبت امتیاز</button><button type="submit" class="secondary-action" id="ref-confirm-cancel">برگشت و اصلاح</button></div></form></dialog>
<script nonce="<?= $escape($nonce) ?>">
(() => {
  const password = document.getElementById('ref-password');
  document.getElementById('ref-password-toggle')?.addEventListener('click', () => { password.type = password.type === 'password' ? 'text' : 'password'; });
  const back = document.getElementById('ref-back');
  if (!back) return;
  const logoutForm = document.getElementById('ref-logout-form');
  const games = <?= json_encode($games, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) ?>;
  const currentPeriod = <?= json_encode($activePeriod, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) ?>;
  const csrf = <?= json_encode($_SESSION['ref_monitor_csrf'], JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) ?>;
  const views = [...document.querySelectorAll('[data-ref-view]')];
  const gameTitle = document.getElementById('ref-game-title');
  const teamsList = document.getElementById('ref-teams-list');
  const selectedList = document.getElementById('ref-selected-list');
  const resultList = document.getElementById('ref-search-results');
  const selected = new Map();
  let activeGame = null;
  const activePeriod = currentPeriod?.code || '';
  let activeTeam = null;
  let createdTeamToOpen = null;
  let teamsCache = [];
  let pendingScore = null;
  let scoreSaving = false;
  let activeScoreLevelId = null;
  let editingTeamId = null;
  let results = [];
  let memberDeadline = 0;
  let teamStep = 'name';
  let searchTimer = 0;
  let searchController = null;
  let searchSequence = 0;
  const setStatus = (id, message, kind = '') => {
    const node = document.getElementById(id);
    node.textContent = message;
    node.className = 'status-text' + (kind ? ' ' + kind : '');
  };
  const request = async (action, fields = {}, options = {}) => {
    const body = new URLSearchParams({action, csrf, period_code: activePeriod, game_id: activeGame?.id || ''});
    for (const [key, value] of Object.entries(fields)) {
      if (Array.isArray(value)) value.forEach(item => body.append(key + '[]', String(item)));
      else body.set(key, String(value));
    }
    const response = await fetch(location.pathname, {method:'POST', credentials:'same-origin', body, signal:options.signal});
    let data;
    try {
      data = await response.json();
    } catch {
      throw new Error(`پاسخ سرور معتبر نیست (HTTP ${response.status}). صفحه را تازه‌سازی کنید و دوباره تلاش کنید.`);
    }
    if (!response.ok || data.status !== 'ok') throw new Error(data.message || 'درخواست انجام نشد.');
    return data;
  };
  const personItem = (person, action, label) => {
    const item = document.createElement('li');
    item.className = 'person-card';
    const details = document.createElement('span');
    const name = document.createElement('strong');
    name.textContent = person.name || 'بدون نام';
    const codes = document.createElement('small');
    codes.textContent = `${person.work_id ? `کد پرسنلی ${person.work_id}` : `کد ملی ${person.national_id || '—'}`}${activeGame?.gender_mode === 'separated' ? ` · ${person.gender === 'male' ? 'مرد' : person.gender === 'female' ? 'زن' : 'جنسیت نامشخص'}` : ''}`;
    details.append(name, codes);
    const button = document.createElement('button');
    button.type = 'button';
    button.className = 'secondary-action';
    button.textContent = label;
    button.addEventListener('click', action);
    item.append(details, button);
    return item;
  };
  const coverColors = <?= json_encode(EGM_REF_COVER_COLORS, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) ?>;
  const coverInput = document.getElementById('ref-team-cover-color');
  const fillCoverSelect = (select, value = '') => {
    select.replaceChildren(new Option('انتخاب رنگ', ''));
    for (const color of coverColors) select.append(new Option(color, color));
    if (value && !coverColors.includes(value)) select.append(new Option(`${value} (ثبت قبلی)`, value));
    select.value = value;
  };
  fillCoverSelect(coverInput);
  const syncCoverChoices = () => coverInput.setCustomValidity(coverInput.required && !coverInput.value ? 'رنگ پوشش تیم را انتخاب کنید.' : '');
  coverInput.addEventListener('change', syncCoverChoices);
  const editDialog = document.getElementById('ref-team-edit');
  let editSaving = false;
  document.getElementById('ref-edit-name').addEventListener('click', () => {
    if (!activeTeam || activeTeam.ended_at) return;
    document.getElementById('ref-detail-name').value = activeTeam.name;
    const colorSelect = document.getElementById('ref-detail-cover-input');
    fillCoverSelect(colorSelect, activeTeam.cover_color || '');
    colorSelect.required = !!activeGame.require_cover_color;
    document.getElementById('ref-edit-color-field').classList.toggle('hidden', !activeGame.require_cover_color && !activeTeam.cover_color);
    updateMemberTimer(); setStatus('ref-edit-status', ''); editDialog.showModal();
  });
  editDialog.addEventListener('cancel', event => { if (editSaving) event.preventDefault(); });
  document.getElementById('ref-edit-cancel').addEventListener('click', () => { if (!editSaving) editDialog.close(); });
  document.getElementById('ref-team-edit-form').addEventListener('submit', async event => {
    event.preventDefault();
    if (!activeTeam || activeTeam.ended_at || editSaving || !event.target.reportValidity()) return;
    editSaving = true;
    const controls = [...event.target.querySelectorAll('button')]; controls.forEach(button => button.disabled = true);
    try {
      const team = (await request('update_team_details', {team_id:activeTeam.id, name:document.getElementById('ref-detail-name').value.trim(), cover_color:document.getElementById('ref-detail-cover-input').value})).team;
      activeTeam = team; editDialog.close(); renderTeamDetail();
    } catch (error) { setStatus('ref-edit-status', error.message, 'error'); }
    finally { editSaving = false; controls.forEach(button => button.disabled = false); }
  });
  const renderSelected = () => {
    selectedList.replaceChildren();
    for (const person of selected.values()) selectedList.append(personItem(person, () => { selected.delete(person.id); renderSelected(); renderResults(); }, 'حذف'));
    document.getElementById('ref-member-count').textContent = `(${selected.size})`;
    document.getElementById('ref-selected-card').classList.toggle('hidden', selected.size === 0);
    document.getElementById('ref-team-next-members').disabled = selected.size === 0 || selected.size > (activeGame?.max_players || 20);
  };
  const renderReview = () => {
    const submitButton = document.getElementById('ref-submit-team');
    submitButton.disabled = false;
    document.getElementById('ref-review-name').textContent = editingTeamId === null ? document.getElementById('ref-team-name').value.trim() : activeTeam?.name || 'تیم';
    document.getElementById('ref-review-count').textContent = `${selected.size} عضو`;
    const cover = document.getElementById('ref-review-cover');
    const color = editingTeamId === null ? document.getElementById('ref-team-cover-color').value.trim() : activeTeam?.cover_color || '';
    cover.textContent = `رنگ پوشش: ${color}`; cover.classList.toggle('hidden', !color);
    const list = document.getElementById('ref-review-members');
    list.replaceChildren();
    for (const person of selected.values()) {
      const item = document.createElement('li'); item.textContent = person.name || person.work_id || person.national_id || 'بدون نام'; list.append(item);
    }
    submitButton.textContent = editingTeamId === null ? 'ثبت تیم' : 'ذخیره اعضا';
  };
  const renderResults = () => {
    resultList.replaceChildren();
    for (const person of results) {
      if (!selected.has(person.id)) resultList.append(personItem(person, () => {
        if (selected.size >= (activeGame?.max_players || 20)) { setStatus('ref-search-status', `هر تیم در این بازی حداکثر ${activeGame?.max_players || 20} عضو دارد.`, 'error'); return; }
        if (activeGame?.gender_mode === 'separated') {
          if (!person.gender) { setStatus('ref-search-status', 'جنسیت این فرد مشخص نیست و نمی‌توان او را به تیم افزود.', 'error'); return; }
          if ([...selected.values()].some(member => member.gender && member.gender !== person.gender)) {
            setStatus('ref-search-status', 'اعضای این تیم باید همگی مرد یا همگی زن باشند.', 'error'); return;
          }
        }
        selected.set(person.id, person); renderSelected(); renderResults();
      }, 'افزودن'));
    }
  };
  const resetSearch = () => {
    window.clearTimeout(searchTimer);
    searchController?.abort();
    searchSequence += 1;
    document.getElementById('ref-search-input').value = '';
    results = []; renderResults();
    setStatus('ref-search-status', '');
  };
  const searchInvitees = async query => {
    searchController?.abort();
    searchController = new AbortController();
    const sequence = ++searchSequence;
    setStatus('ref-search-status', 'در حال جستجو…');
    try {
      const data = await request('search_invitees', {query}, {signal:searchController.signal});
      if (sequence !== searchSequence) return;
      results = data.invitees; renderResults();
      setStatus('ref-search-status', results.length ? '' : 'موردی پیدا نشد؛ فقط دعوت‌شدگان بازهٔ فعال نمایش داده می‌شوند.');
    } catch (error) {
      if (error.name === 'AbortError' || sequence !== searchSequence) return;
      results = []; renderResults(); setStatus('ref-search-status', error.message, 'error');
    }
  };
  const normalizeSearch = value => String(value || '').normalize('NFKC').replace(/ي/g, 'ی').replace(/ك/g, 'ک').replace(/[\u200c\u200f]/g, ' ').toLocaleLowerCase().trim();
  const teamState = team => team.ended_at ? 'completed' : team.waiting_for_room ? 'waiting' : team.started_at ? 'playing' : 'ready';
  const renderTeams = () => {
    const query = normalizeSearch(document.getElementById('ref-team-filter').value);
    const filtered = teamsCache.filter(team => normalizeSearch([team.name, ...team.members.flatMap(member => [member.name, member.work_id])].join(' ')).includes(query));
    teamsList.replaceChildren();
    setStatus('ref-teams-status', filtered.length ? `${filtered.length} تیم` : teamsCache.length ? 'تیمی با این نام یا عضو پیدا نشد.' : 'هنوز تیمی ثبت نشده است.');
    for (const [key, label] of [['ready','آماده شروع'], ['waiting','در انتظار اتاق'], ['playing','در حال بازی'], ['completed','پایان‌یافته']]) {
      const teams = filtered.filter(team => teamState(team) === key);
      if (!teams.length) continue;
      const group = document.createElement('li'); group.className = 'team-group';
      const heading = document.createElement('h3'); heading.className = 'team-group-title'; heading.textContent = `${label} (${teams.length})`;
      const list = document.createElement('ul'); list.className = 'team-list';
      for (const team of teams) {
        const item = document.createElement('li');
        const button = document.createElement('button'); button.type = 'button'; button.className = 'team-card';
        const title = document.createElement('strong'); title.textContent = team.name;
        const members = document.createElement('small'); members.textContent = `${team.members.length} عضو`;
        const state = document.createElement('small'); state.className = `team-state ${key}`; state.textContent = label;
        button.append(title, members, state);
        if (team.cover_color) { const color = document.createElement('span'); color.className = 'cover-badge'; color.textContent = `پوشش: ${team.cover_color}`; button.append(color); }
        if (activeGame.auto_room_manager && team.room_assignment && !team.ended_at) {
          const room = document.createElement('span'); room.className = 'team-room-name'; room.textContent = team.room_assignment.room_name; button.append(room);
        }
        if (team.started_at) { const score = document.createElement('small'); score.textContent = `امتیاز کل: ${team.total_score}`; button.append(score); }
        button.addEventListener('click', () => { activeTeam = team; open('team-detail', activeGame.id, activePeriod, team.id); });
        item.append(button); list.append(item);
      }
      group.append(heading, list); teamsList.append(group);
    }
  };
  document.getElementById('ref-team-filter').addEventListener('input', renderTeams);
  const loadTeams = async (silent = false) => {
    if (!activePeriod) { setStatus('ref-teams-status', 'در حال حاضر بازهٔ فعالی وجود ندارد.'); return; }
    const gameId = activeGame?.id;
    if (!silent) setStatus('ref-teams-status', 'در حال بارگذاری تیم‌ها…');
    try {
      const data = await request('list_teams');
      if (gameId !== activeGame?.id) return;
      teamsCache = data.teams; renderTeams();
    } catch (error) { setStatus('ref-teams-status', error.message, 'error'); }
  };
  const updateMemberTimer = () => {
    if (!activeTeam) return;
    const left = activeTeam.started_at ? Math.max(0, Math.ceil((memberDeadline - Date.now()) / 1000)) : null;
    const canEdit = activeTeam.can_edit_members && (left === null || left > 0);
    document.getElementById('ref-edit-members').classList.toggle('hidden', !canEdit);
    setStatus('ref-member-hint', !canEdit || left === null ? ''
      : `ویرایش اعضا: ${Math.floor(left / 60).toString().padStart(2, '0')}:${(left % 60).toString().padStart(2, '0')}`);
  };
  const scoreSteps = game => game.has_levels ? (game.levels || []) : [{id:'game_total', name:'امتیاز بازی'}];
  const renderRoomGuidance = (card, assignment) => {
    const key = assignment ? `${assignment.level_id}:${assignment.room_id || assignment.room_name}` : '';
    const changed = assignment && card.dataset.assignment !== key;
    card.dataset.assignment = key;
    card.classList.toggle('room-arrived', !!changed);
    card.replaceChildren();
    card.classList.toggle('waiting', !assignment);
    const instruction = document.createElement('p'); instruction.className = 'room-instruction';
    instruction.textContent = assignment ? 'مقصد تیم' : 'تخصیص اتاق';
    const name = document.createElement('h2'); name.className = 'room-name';
    name.textContent = assignment ? assignment.room_name : 'در انتظار اتاق';
    const stage = document.createElement('p'); stage.className = 'room-stage';
    stage.textContent = assignment ? assignment.level_name : 'به‌صورت خودکار مشخص می‌شود';
    card.append(instruction, name, stage);
  };
  const renderTeamDetail = () => {
    if (!activeTeam || !activeGame) return;
    document.getElementById('ref-detail-title').textContent = activeTeam.name;
    setStatus('ref-detail-state', activeTeam.ended_at ? 'پایان‌یافته' : activeTeam.started_at ? 'در جریان' : 'آماده شروع', activeTeam.ended_at ? 'success' : '');
    document.getElementById('ref-detail-overview').textContent = activeGame.name;
    const color = activeTeam.cover_color || '';
    document.getElementById('ref-cover-detail').classList.toggle('hidden', !activeGame.require_cover_color && !color);
    document.getElementById('ref-detail-cover').textContent = color ? `رنگ پوشش: ${color}` : 'رنگ پوشش ثبت نشده است';



    const roomCard = document.getElementById('ref-room-card');
    roomCard.classList.toggle('hidden', !activeGame.auto_room_manager || !activeTeam.started_at || !!activeTeam.ended_at);
    if (activeGame.auto_room_manager && activeTeam.started_at && !activeTeam.ended_at) {
      renderRoomGuidance(roomCard, activeTeam.room_assignment);
    }
    document.getElementById('ref-completion-card').classList.toggle('hidden', !activeTeam.ended_at);
    document.getElementById('ref-completion-score').textContent = `امتیاز نهایی: ${activeTeam.total_score}`;
    const startButton = document.getElementById('ref-start-team');
    startButton.classList.toggle('hidden', !!activeTeam.started_at || !!activeTeam.ended_at);
    const scoreButton = document.getElementById('ref-open-scores');
    scoreButton.textContent = activeGame.auto_room_manager ? 'پایان بازی و ثبت امتیاز' : 'ثبت امتیاز';
    const hasPendingScores = scoreSteps(activeGame).some(level => !activeTeam.scores?.[level.id]);
    scoreButton.classList.toggle('hidden', !activeTeam.started_at || !!activeTeam.ended_at || !hasPendingScores || (activeGame.auto_room_manager && !activeTeam.room_assignment));
    document.getElementById('ref-detail-dock').classList.toggle('hidden', startButton.classList.contains('hidden') && scoreButton.classList.contains('hidden'));
    const count = activeTeam.members.length;
    const withinLimits = count >= activeGame.min_players && count <= activeGame.max_players;
    const missingColor = activeGame.require_cover_color && !color;
    startButton.disabled = !withinLimits || missingColor;
    setStatus('ref-start-hint', activeTeam.started_at || activeTeam.ended_at ? ''
      : missingColor ? 'برای شروع بازی، ابتدا رنگ پوشش تیم را ثبت کنید.'
      : withinLimits ? ''
      : `برای شروع بازی، تیم باید بین ${activeGame.min_players} تا ${activeGame.max_players} عضو داشته باشد.`);

    document.getElementById('ref-edit-name').classList.toggle('hidden', !!activeTeam.ended_at);
    if (!editDialog.open) document.getElementById('ref-detail-name').value = activeTeam.name;
    const membersList = document.getElementById('ref-detail-members');
    document.getElementById('ref-detail-members-title').textContent = `اعضای تیم · ${activeTeam.members.length} نفر`;
    const memberSection = document.getElementById('ref-member-section');
    const memberState = `${activeTeam.id}:${!!activeTeam.started_at}`;
    if (memberSection.dataset.state !== memberState) { memberSection.open = false; memberSection.dataset.state = memberState; }
    membersList.replaceChildren();
    for (const member of activeTeam.members) {
      const item = document.createElement('li');
      const info = document.createElement('span'); info.className = 'member-info';
      const name = document.createElement('span'); name.className = 'member-name';
      name.textContent = member.name || member.work_id || 'بدون نام'; info.append(name);
      if (member.work_id) {
        const code = document.createElement('span'); code.className = 'member-code';
        code.textContent = `کد پرسنلی: ${member.work_id}`; info.append(code);
      }
      item.append(info);
      membersList.append(item);
    }
    memberDeadline = activeTeam.started_at ? Date.now() + (activeTeam.member_edit_seconds_left || 0) * 1000 : 0;
    updateMemberTimer();
    const totalScore = document.getElementById('ref-total-score');
    totalScore.textContent = `امتیاز کل: ${activeTeam.total_score}`;
    totalScore.classList.toggle('hidden', !activeGame.has_levels || !activeTeam.started_at || !Object.keys(activeTeam.scores || {}).length);
  };
  const renderScoreLevels = () => {
    if (!activeTeam || !activeGame) return;
    const levels = scoreSteps(activeGame);
    const list = document.getElementById('ref-score-levels');
    list.replaceChildren();
    setStatus('ref-levels-team', `${activeTeam.name} · ${activeGame.name}`);
    if (activeGame.auto_room_manager) {
      setStatus('ref-levels-status', activeTeam.room_assignment ? `${activeTeam.room_assignment.level_name} · اتاق ${activeTeam.room_assignment.room_name}` : 'در انتظار اتاق');
      if (activeTeam.room_assignment) {
        const item = document.createElement('li');
        const title = document.createElement('span'); title.textContent = `${activeTeam.room_assignment.level_name} · ${activeTeam.room_assignment.room_name}`;
        const button = document.createElement('button'); button.type = 'button'; button.className = 'inline-action'; button.textContent = 'ثبت امتیاز';
        button.addEventListener('click', () => open('score-entry', activeGame.id, activePeriod, activeTeam.id, activeTeam.room_assignment.level_id));
        item.append(title, button); list.append(item);
      }
      return;
    }
    for (const [index, level] of levels.entries()) {
      const item = document.createElement('li');
      const title = document.createElement('span');
      title.textContent = activeGame.has_levels ? `${index + 1}. ${level.name}` : level.name;
      const score = activeTeam.scores?.[level.id];
      if (score) {
        const value = document.createElement('span'); value.textContent = `${score.score} امتیاز`;
        item.append(title, value);
      } else if (activeTeam.ended_at) {
        const value = document.createElement('span'); value.textContent = 'ثبت نشده'; item.append(title, value);
      } else {
        const button = document.createElement('button'); button.type = 'button'; button.className = 'inline-action';
        button.textContent = 'ثبت امتیاز';
        button.addEventListener('click', () => open('score-entry', activeGame.id, activePeriod, activeTeam.id, level.id));
        item.append(title, button);
      }
      list.append(item);
    }
    if (!levels.length) setStatus('ref-levels-status', 'هنوز مرحله‌ای برای این بازی تعریف نشده است.');
    else setStatus('ref-levels-status', '');
  };
  const renderScoreStep = () => {
    if (!activeTeam || !activeGame) return;
    const levels = scoreSteps(activeGame);
    const completed = levels.filter(level => activeTeam.scores?.[level.id]);
    const nextLevel = activeGame.auto_room_manager
      ? levels.find(level => level.id === activeTeam.room_assignment?.level_id && !activeTeam.scores?.[level.id])
      : levels.find(level => level.id === activeScoreLevelId && !activeTeam.scores?.[level.id]) || levels.find(level => !activeTeam.scores?.[level.id]);
    const stage = document.getElementById('ref-score-stage');
    const scoreDock = document.getElementById('ref-score-dock');
    const homeDock = document.getElementById('ref-score-home-dock');
    document.getElementById('ref-score-submit').disabled = false;
    document.getElementById('ref-score-submit').textContent = 'ثبت امتیاز';
    if (activeGame.auto_room_manager) document.getElementById('ref-score-submit').textContent = 'ثبت مجموع امتیاز دورها';
    stage.replaceChildren(); scoreDock.classList.add('hidden'); homeDock.classList.add('hidden');
    const singleScoreGame = !activeGame.has_levels;
    document.getElementById('ref-score-progress').classList.toggle('hidden', singleScoreGame);
    document.getElementById('ref-score-track').classList.toggle('hidden', singleScoreGame);
    document.getElementById('ref-score-progress').textContent = singleScoreGame ? ''
      : activeTeam.ended_at ? `${completed.length} مرحله از ${levels.length} ثبت شد`
      : levels.length ? `${completed.length} از ${levels.length} مرحله ثبت شده` : 'مراحل بازی';
    document.getElementById('ref-score-fill').style.width = levels.length ? `${completed.length / levels.length * 100}%` : '0%';
    setStatus('ref-score-team', `${activeTeam.name}${activeGame.auto_room_manager ? '' : ` · ${activeGame.name}`}${activeTeam.cover_color ? ` · پوشش ${activeTeam.cover_color}` : ''}`);
    if (!levels.length) {
      document.getElementById('ref-score-title').textContent = 'مرحله‌ای تعریف نشده است';
      const message = document.createElement('p'); message.className = 'status-text'; message.textContent = 'مدیر EGM باید ابتدا مراحل این بازی را تعریف کند.'; stage.append(message);
      return;
    }
    if (activeTeam.ended_at || (!nextLevel && !activeGame.auto_room_manager)) {
      document.getElementById('ref-score-title').textContent = 'بازی پایان یافت';
      const message = document.createElement('p'); message.className = 'status-text success'; message.textContent = `امتیاز نهایی: ${activeTeam.total_score}`; stage.append(message);
      homeDock.classList.remove('hidden');
      return;
    }
    if (activeGame.auto_room_manager && !nextLevel) {
      document.getElementById('ref-score-title').textContent = 'در انتظار اتاق';
      const message = document.createElement('p'); message.className = 'status-text'; message.textContent = 'پس از آزاد شدن اتاق، مرحلهٔ بعد نمایش داده می‌شود.'; stage.append(message);
      return;
    }
    document.getElementById('ref-score-title').textContent = activeGame.auto_room_manager ? activeTeam.room_assignment.room_name : nextLevel.name;
    const intro = document.createElement('p'); intro.className = 'status-text'; intro.textContent = activeGame.auto_room_manager ? 'بازی تمام شد؟ مجموع امتیاز دورها را وارد کنید.' : activeGame.has_levels ? 'امتیاز نهایی این مرحله را وارد کنید.' : 'امتیاز نهایی بازی را وارد کنید.';
    const form = document.createElement('form'); form.className = 'score-form'; form.id = 'ref-score-form'; form.dataset.levelId = nextLevel.id;
    const input = document.createElement('input'); input.className = 'login-input score-number'; input.type = 'number'; input.min = '0'; input.max = '999999.99'; input.step = '0.01'; input.required = true; input.placeholder = 'امتیاز'; input.setAttribute('aria-label', `امتیاز ${nextLevel.name}`);
    if (activeGame.auto_room_manager) {
      input.id = 'ref-rounds-total'; input.placeholder = '۰';
      input.setAttribute('aria-label', 'مجموع امتیاز تمام دورهای این اتاق');
      const label = document.createElement('label'); label.className = 'login-field'; label.htmlFor = input.id;
      const title = document.createElement('span'); title.textContent = 'مجموع امتیاز تمام دورها'; label.append(title, input);
      const help = document.createElement('p'); help.className = 'score-help'; help.id = 'ref-rounds-help';
      help.textContent = 'امتیاز دورها را با هم جمع کنید و عدد نهایی را وارد کنید؛ مثلاً ۱۰ + ۱۵ + ۲۰ = ۴۵.';
      const calculation = document.createElement('details'); calculation.className = 'score-calculation';
      const summary = document.createElement('summary'); summary.textContent = 'روش محاسبهٔ مجموع امتیاز'; calculation.append(summary, help);
      input.setAttribute('aria-describedby', help.id); form.append(label, calculation);
    } else form.append(input);
    stage.append(intro, form); scoreDock.classList.remove('hidden');
  };
  const loadTeamDetail = async teamId => {
    const scoreListView = views.some(view => view.dataset.refView === 'score' && !view.classList.contains('hidden'));
    const scoreEntryView = views.some(view => view.dataset.refView === 'score-entry' && !view.classList.contains('hidden'));
    const statusId = scoreEntryView ? 'ref-score-step-status' : scoreListView ? 'ref-levels-status' : 'ref-score-status';
    setStatus(statusId, 'در حال بارگذاری تیم…');
    try {
      activeTeam = (await request('team_detail', {team_id:teamId})).team;
      renderTeamDetail();
      if (scoreListView) renderScoreLevels();
      if (scoreEntryView) renderScoreStep();
      setStatus(statusId, '');
    } catch (error) { setStatus(statusId, error.message, 'error'); }
  };
  const show = (name, state = {}) => {
    if (confirmation?.open && !scoreSaving) confirmation.close();
    if (editDialog.open && !editSaving) editDialog.close();
    const target = views.find(view => view.dataset.refView === name) || views[0];
    for (const view of views) view.classList.toggle('hidden', view !== target);
    const isHome = target === views[0];
    back.classList.toggle('hidden', isHome);
    logoutForm.classList.toggle('hidden', !isHome);
    if (name === 'game' || name === 'team' || name === 'team-detail' || name === 'score' || name === 'score-entry') {
      activeGame = games.find(game => game.id === state.gameId) || activeGame;
      if (!activeGame) return;
      if (name === 'game') {
        document.getElementById('ref-team-filter').value = '';
        teamsCache = []; teamsList.replaceChildren();
        gameTitle.textContent = activeGame.name;
        setStatus('ref-game-period', `بازهٔ فعال: ${currentPeriod?.title || activePeriod}`);
        loadTeams();
      } else if (name === 'team') {
        const coverInput = document.getElementById('ref-team-cover-color');
        document.getElementById('ref-cover-picker').classList.toggle('hidden', !activeGame.require_cover_color || !!state.teamId);
        coverInput.required = !!activeGame.require_cover_color && !state.teamId;
        syncCoverChoices();
        setStatus('ref-team-context', `${activeGame.name} · ${currentPeriod?.title || activePeriod}`);
        const editing = !!state.teamId;
        editingTeamId = editing ? Number(state.teamId) : null;
        document.getElementById('ref-team-form-title').textContent = editing ? 'ویرایش اعضای تیم' : 'تشکیل تیم';
        teamStep = state.step || (editing ? 'members' : 'name');
        for (const panel of document.querySelectorAll('[data-team-step]')) panel.classList.toggle('hidden', panel.dataset.teamStep !== teamStep);
        for (const dock of document.querySelectorAll('[data-team-action]')) dock.classList.toggle('hidden', dock.dataset.teamAction !== teamStep);
        const stepNumber = editing ? (teamStep === 'members' ? 1 : 2) : teamStep === 'name' ? 1 : teamStep === 'members' ? 2 : 3;
        const stepTotal = editing ? 2 : 3;
        document.getElementById('ref-step-fill').style.width = `${stepNumber / stepTotal * 100}%`;
        setStatus('ref-step-label', `${stepNumber} از ${stepTotal} · ${teamStep === 'name' ? 'نام تیم' : teamStep === 'members' ? 'اعضا' : 'بازبینی'}`);
        if (teamStep === 'review') renderReview();
      } else if (name === 'team-detail' || name === 'score' || name === 'score-entry') {

        setStatus('ref-journey-status', '');
        activeScoreLevelId = name === 'score-entry' ? (state.step || null) : null;
        if (name === 'score-entry') {
          document.getElementById('ref-score-stage').replaceChildren();
          document.getElementById('ref-score-dock').classList.add('hidden');
          document.getElementById('ref-score-home-dock').classList.add('hidden');
        }
        loadTeamDetail(state.teamId || activeTeam?.id);
      }
    }
  };
  history.replaceState({refMonitor:true,view:'home'}, '', location.href);
  const open = (view, gameId = activeGame?.id, periodCode = activePeriod, teamId = null, step = null) => {
    const state = {refMonitor:true, view, gameId, periodCode, teamId, step};
    history.pushState(state, '', location.href);
    show(view, state);
  };
  window.RefMonitorNavigation = {open, back() { if (!back.classList.contains('hidden')) history.back(); }};
  document.querySelectorAll('[data-open-game]').forEach(button => button.addEventListener('click', () => open('game', button.dataset.openGame)));
  document.getElementById('ref-new-team').addEventListener('click', () => {
    if (!activePeriod) return;
    activeTeam = null;
    selected.clear(); renderSelected(); resetSearch();
    document.getElementById('ref-team-name').value = '';
    document.getElementById('ref-team-cover-color').value = '';
    syncCoverChoices();
    setStatus('ref-submit-status', '');
    open('team', activeGame.id, activePeriod, null, 'name');
  });
  document.getElementById('ref-team-next-name').addEventListener('click', () => {
    if (!document.getElementById('ref-team-name').reportValidity()) return;
    if (activeGame.require_cover_color && !document.getElementById('ref-team-cover-color').reportValidity()) return;
    open('team', activeGame.id, activePeriod, null, 'members');
  });
  document.getElementById('ref-team-next-members').addEventListener('click', () => {
    if (!selected.size || selected.size > activeGame.max_players) return;
    open('team', activeGame.id, activePeriod, editingTeamId, 'review');
  });
  document.getElementById('ref-edit-members').addEventListener('click', () => {
    if (!activeTeam?.can_edit_members || editSaving) return;
    editDialog.close();
    selected.clear(); resetSearch();
    for (const member of activeTeam.members) selected.set(member.id, member);
    renderSelected();
    setStatus('ref-submit-status', '');
    open('team', activeGame.id, activePeriod, activeTeam.id, 'members');
  });
  document.getElementById('ref-start-team').addEventListener('click', async event => {
    if (!activeTeam || activeTeam.started_at || activeTeam.ended_at) return;
    const button = event.currentTarget;
    button.disabled = true;
    setStatus('ref-start-hint', 'در حال شروع بازی…');
    try {
      activeTeam = (await request('start_team', {team_id:activeTeam.id})).team;
      renderTeamDetail();
      if (activeGame.auto_room_manager) {
        document.getElementById('ref-room-card').scrollIntoView({block:'start', behavior:window.matchMedia('(prefers-reduced-motion: reduce)').matches ? 'auto' : 'smooth'});
        setStatus('ref-journey-status', activeTeam.room_assignment ? 'بازی شروع شد.' : 'منتظر اتاق بمانید.', 'success');
      }
      setStatus('ref-start-hint', '');
    } catch (error) { setStatus('ref-start-hint', error.message, 'error'); button.disabled = false; }
  });
  document.getElementById('ref-open-scores').addEventListener('click', () => {
    if (!activeTeam?.started_at || activeTeam.ended_at) return;
    if (activeGame.auto_room_manager) {
      if (activeTeam.room_assignment) open('score-entry', activeGame.id, activePeriod, activeTeam.id, activeTeam.room_assignment.level_id);
      return;
    }
    open('score', activeGame.id, activePeriod, activeTeam.id);
  });
  document.getElementById('ref-score-home').addEventListener('click', () => open('home'));
  document.getElementById('ref-completion-back').addEventListener('click', () => {
    history.replaceState({refMonitor:true, view:'game', gameId:activeGame.id, periodCode:activePeriod}, '', location.href);
    show('game', {gameId:activeGame.id});
  });
  const confirmation = document.getElementById('ref-score-confirm');
  confirmation.addEventListener('cancel', event => { if (scoreSaving) event.preventDefault(); });
  confirmation.addEventListener('close', () => { if (!scoreSaving) pendingScore = null; });
  document.getElementById('ref-score-stage').addEventListener('submit', event => {
    const form = event.target.closest('[data-level-id]');
    if (!form || !activeTeam || scoreSaving) return;
    event.preventDefault();
    if (!form.reportValidity()) return;
    const level = scoreSteps(activeGame).find(item => item.id === form.dataset.levelId);
    pendingScore = {team_id:activeTeam.id, game_id:activeGame.id, level_id:form.dataset.levelId, score:form.querySelector('input').value};
    document.getElementById('ref-confirm-team').textContent = `تیم: ${activeTeam.name}${activeTeam.cover_color ? ` · پوشش ${activeTeam.cover_color}` : ''}`;
    document.getElementById('ref-confirm-room').textContent = activeGame.auto_room_manager ? `اتاق: ${activeTeam.room_assignment?.room_name || 'تعیین نشده'} · ${level?.name || ''}` : `${activeGame.name} · ${level?.name || ''}`;
    document.getElementById('ref-confirm-score').textContent = `مجموع امتیاز: ${pendingScore.score}`;
    setStatus('ref-confirm-status', '');
    confirmation.showModal();
    document.getElementById('ref-confirm-cancel').focus();
  });
  document.getElementById('ref-confirm-save').addEventListener('click', async () => {
    if (!pendingScore || scoreSaving) return;
    if (pendingScore.team_id !== activeTeam?.id || pendingScore.game_id !== activeGame?.id) { confirmation.close(); return; }
    const fields = {...pendingScore};
    scoreSaving = true;
    const save = document.getElementById('ref-confirm-save');
    const cancel = document.getElementById('ref-confirm-cancel');
    save.disabled = true; cancel.disabled = true;
    setStatus('ref-confirm-status', 'در حال ثبت امتیاز…');
    try {
      activeTeam = (await request('submit_score', fields)).team;
      scoreSaving = false; pendingScore = null; confirmation.close();
      renderTeamDetail();
      if (activeGame.auto_room_manager || activeTeam.ended_at) {
        const state = {refMonitor:true, view:'team-detail', gameId:activeGame.id, periodCode:activePeriod, teamId:activeTeam.id};
        history.replaceState(state, '', location.href);
        for (const view of views) view.classList.toggle('hidden', view.dataset.refView !== 'team-detail');
        setStatus('ref-journey-status', activeTeam.ended_at ? 'امتیاز نهایی ثبت شد.' : activeTeam.room_assignment ? 'امتیاز ثبت شد؛ به اتاق بعدی بروید.' : 'امتیاز ثبت شد؛ منتظر اتاق بعدی بمانید.', 'success');
        document.getElementById(activeTeam.ended_at ? 'ref-completion-card' : 'ref-room-card').scrollIntoView({block:'start', behavior:window.matchMedia('(prefers-reduced-motion: reduce)').matches ? 'auto' : 'smooth'});
      } else history.back();
    } catch (error) {
      scoreSaving = false;
      setStatus('ref-confirm-status', error.message, 'error');
    } finally { save.disabled = false; cancel.disabled = false; }
  });
  document.getElementById('ref-search-input').addEventListener('input', event => {
    if (event.isComposing) return;
    window.clearTimeout(searchTimer);
    searchController?.abort();
    searchSequence += 1;
    results = []; renderResults();
    const query = event.currentTarget.value.trim();
    if ([...query].length < 2) {
      setStatus('ref-search-status', query ? 'حداقل ۲ نویسه' : '');
      return;
    }
    setStatus('ref-search-status', 'در حال جستجو…');
    searchTimer = window.setTimeout(() => searchInvitees(query), 280);
  });
  document.getElementById('ref-search-input').addEventListener('compositionend', event => event.currentTarget.dispatchEvent(new Event('input', {bubbles:true})));
  document.getElementById('ref-submit-team').addEventListener('click', async event => {
    const button = event.currentTarget;
    if (!selected.size) return;
    const editing = editingTeamId !== null;
    const teamName = document.getElementById('ref-team-name');
    if (!editing && !teamName.reportValidity()) return;
    if (!editing && activeGame.require_cover_color && !document.getElementById('ref-team-cover-color').reportValidity()) return;
    button.disabled = true;
    setStatus('ref-submit-status', editing ? 'در حال ذخیرهٔ اعضا…' : 'در حال ثبت تیم…');
    try {
      const fields = {members:[...selected.keys()]};
      if (editing) fields.team_id = editingTeamId; else { fields.name = teamName.value.trim(); fields.cover_color = activeGame.require_cover_color ? document.getElementById('ref-team-cover-color').value.trim() : ''; }
      const data = await request(editing ? 'update_members' : 'create_team', fields);
      activeTeam = data.team;
      if (!editing) createdTeamToOpen = data.team;
      setStatus('ref-submit-status', editing ? 'اعضای تیم ذخیره شدند.' : 'تیم ثبت شد.', 'success');
      history.go(editing ? -2 : -3);
    } catch (error) { setStatus('ref-submit-status', error.message, 'error'); button.disabled = false; }
  });
  back.addEventListener('click', () => window.RefMonitorNavigation.back());
  window.addEventListener('popstate', event => {
    if (createdTeamToOpen) {
      const team = createdTeamToOpen;
      createdTeamToOpen = null;
      open('team-detail', activeGame.id, activePeriod, team.id);
      return;
    }
    show(event.state?.refMonitor ? event.state.view : 'home', event.state || {});
  });
  const checkPeriod = async () => {
    try {
      const data = await request('period_status');
      if (data.period_code !== activePeriod) location.reload();
    } catch (_) { /* The next action will display the connection error. */ }
  };
  window.setInterval(checkPeriod, 30000);
  window.setInterval(updateMemberTimer, 1000);
  window.setInterval(async () => {
    if (document.hidden || !activeGame?.auto_room_manager) return;
    const gameVisible = views.some(view => view.dataset.refView === 'game' && !view.classList.contains('hidden'));
    if (gameVisible) { void loadTeams(true); return; }
    if (!activeTeam?.waiting_for_room) return;
    const detailVisible = views.some(view => view.dataset.refView === 'team-detail' && !view.classList.contains('hidden'));
    if (!detailVisible) return;
    try {
      const teamId = activeTeam.id;
      const gameId = activeGame.id;
      const updated = (await request('team_detail', {team_id:activeTeam.id})).team;
      if (teamId !== activeTeam?.id || gameId !== activeGame?.id) return;
      if (updated.room_assignment || updated.ended_at) {
        activeTeam = updated; renderTeamDetail();
        setStatus('ref-journey-status', updated.ended_at ? 'بازی پایان یافت.' : 'اتاق آماده شد.', 'success');
        document.getElementById(updated.ended_at ? 'ref-completion-card' : 'ref-room-card').scrollIntoView({block:'start', behavior:window.matchMedia('(prefers-reduced-motion: reduce)').matches ? 'auto' : 'smooth'});
      } else setStatus('ref-journey-status', 'در انتظار اتاق · بررسی خودکار');
    } catch (_) { setStatus('ref-journey-status', 'بررسی اتاق ناموفق بود؛ اتصال را بررسی کنید. تلاش خودکار ادامه دارد.', 'error'); }
  }, 3000);
  document.addEventListener('visibilitychange', () => { if (!document.hidden) checkPeriod(); });
})();
</script>
</body></html>
